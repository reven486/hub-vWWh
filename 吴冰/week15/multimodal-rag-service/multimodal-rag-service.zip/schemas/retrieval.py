from pydantic import BaseModel
from typing import List, Optional, Literal


class RetrieveRequest(BaseModel):
    query: str
    collection_name: str = "rag_data_new"
    top_k: int = 5
    modalities: List[Literal["text", "image"]] = ["text", "image"]


class RetrieveResult(BaseModel):
    type: Literal["text", "image"]
    content: Optional[str] = None
    image_url: Optional[str] = None
    caption: Optional[str] = None
    source_file: str
    source_page: Optional[int] = None
    score: float


class RetrieveResponse(BaseModel):
    results: List[RetrieveResult]
