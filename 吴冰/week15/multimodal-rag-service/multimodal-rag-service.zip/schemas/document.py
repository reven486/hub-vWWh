from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class DocumentUploadResponse(BaseModel):
    id: int
    filename: str
    filestate: str


class DocumentInfo(BaseModel):
    id: int
    filename: str
    filepath: str
    filestate: str
    created_at: Optional[datetime] = None


class DocumentStatusResponse(BaseModel):
    id: int
    filename: str
    filestate: str
