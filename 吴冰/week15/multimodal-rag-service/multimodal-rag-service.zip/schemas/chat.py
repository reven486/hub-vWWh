from pydantic import BaseModel
from typing import List, Optional, Literal


class SourceInfo(BaseModel):
    type: Literal["text", "image"]
    file: str
    page: Optional[int] = None
    content: Optional[str] = None
    url: Optional[str] = None


class ChatRequest(BaseModel):
    query: str
    collection_name: str = "rag_data_new"
    top_k: int = 5
    stream: bool = False


class ChatResponse(BaseModel):
    answer: str
    sources: List[SourceInfo]
