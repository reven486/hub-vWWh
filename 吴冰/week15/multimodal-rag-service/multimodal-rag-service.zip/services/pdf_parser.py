import os
import subprocess
import logging

from config import MINERU_SERVICE_URL, MINERU_TIMEOUT, PROCESSED_DIR

logger = logging.getLogger(__name__)


def parse_pdf(pdf_path: str) -> str:
    """调用 MinerU 将 PDF 解析为 markdown + 图片。

    返回解析后的 markdown 文件路径。
    """
    output_dir = PROCESSED_DIR
    cmd = (
        f"mineru -p {pdf_path} -o {output_dir} "
        f"-b vlm-http-client -u {MINERU_SERVICE_URL}"
    )
    logger.info(f"Running MinerU: {cmd}")
    subprocess.check_output(cmd, shell=True, timeout=MINERU_TIMEOUT)

    # 查找生成的 markdown 文件
    import glob
    base_name = os.path.splitext(os.path.basename(pdf_path))[0]
    md_pattern = os.path.join(output_dir, base_name, "**", "*.md")
    md_files = glob.glob(md_pattern, recursive=True)

    if not md_files:
        raise FileNotFoundError(f"MinerU did not produce markdown for {pdf_path}")

    return md_files[0]
