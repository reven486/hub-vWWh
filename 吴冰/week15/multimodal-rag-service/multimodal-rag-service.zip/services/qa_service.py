import openai
import logging

from config import LLM_API_KEY, LLM_BASE_URL, LLM_MODEL

logger = logging.getLogger(__name__)

_client = openai.OpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)

RAG_PROMPT = """基于以下资料回答问题：

问题：{question}

相关资料：
{context}

回答要求：
- 回答要客观、有逻辑，严格基于提供的资料。
- 如果资料中包含图片，请将图片放在相关的内容位置，并保留原始链接。
- 请在回答中标注信息来源（如文件名、页码等）。
"""


def generate_answer(query: str, context: str) -> str:
    """调用 LLM 生成基于检索结果的答案。"""
    messages = [
        {"role": "system", "content": "你是一个多模态 RAG 助手，基于检索到的资料回答问题。"},
        {"role": "user", "content": RAG_PROMPT.format(question=query, context=context)},
    ]

    completion = _client.chat.completions.create(
        model=LLM_MODEL,
        messages=messages,
    )
    return completion.choices[0].message.content
