import os
import logging

from sentence_transformers import SentenceTransformer
from pymilvus import MilvusClient
from config import BGE_MODEL_PATH, CLIP_MODEL_PATH, BGE_DIM, CLIP_DIM, COLLECTION_NAME

logger = logging.getLogger(__name__)

_bge_model = None
_clip_model = None


def get_bge_model() -> SentenceTransformer:
    global _bge_model
    if _bge_model is None:
        logger.info(f"Loading BGE model from {BGE_MODEL_PATH}")
        _bge_model = SentenceTransformer(BGE_MODEL_PATH)
    return _bge_model


def get_clip_model() -> SentenceTransformer:
    global _clip_model
    if _clip_model is None:
        logger.info(f"Loading CLIP model from {CLIP_MODEL_PATH}")
        _clip_model = SentenceTransformer(CLIP_MODEL_PATH, trust_remote_code=True, truncate_dim=CLIP_DIM)
    return _clip_model


def encode_text(text: str) -> tuple[list[float], list[float]]:
    """对纯文本进行 BGE + CLIP 编码。

    返回 (bge_embedding, clip_text_embedding)。
    """
    bge_model = get_bge_model()
    clip_model = get_clip_model()

    try:
        bge_emb = bge_model.encode(text, normalize_embeddings=True)
        bge_emb = list(bge_emb)
    except Exception:
        logger.exception("BGE encoding failed")
        bge_emb = [0.0] * BGE_DIM

    try:
        clip_emb = clip_model.encode(text, normalize_embeddings=True)
        clip_emb = list(clip_emb)
    except Exception:
        logger.exception("CLIP text encoding failed")
        clip_emb = [0.0] * CLIP_DIM

    return bge_emb, clip_emb


def encode_image(image_path: str) -> list[float]:
    """对图片进行 CLIP 编码。

    返回 clip_image_embedding。
    """
    clip_model = get_clip_model()

    if not os.path.exists(image_path):
        logger.warning(f"Image not found: {image_path}")
        return [0.0] * CLIP_DIM

    try:
        logger.info(f"Encoding image: {image_path}")
        emb = clip_model.encode(image_path, normalize_embeddings=True)
        return list(emb)
    except Exception:
        logger.exception("CLIP image encoding failed")
        return [0.0] * CLIP_DIM


def ensure_collection():
    """确保 Milvus collection 存在且 schema/index 正确。

    首次启动时自动创建 collection，包含三个向量字段：
    - text_vector (BGE, 512 dim)
    - clip_text_vector (CLIP text, 1024 dim)
    - clip_image_vector (CLIP image, 1024 dim)
    """
    client = get_client()

    if client.has_collection(collection_name=COLLECTION_NAME):
        logger.info(f"Collection '{COLLECTION_NAME}' already exists, skipping creation")
        return

    logger.info(f"Creating collection '{COLLECTION_NAME}'...")

    schema = {
        "auto_id": True,
        "enable_dynamic_field": False,
        "fields": [
            {"field_name": "id", "is_primary": True, "data_type": "INT64", "auto_id": True},
            {"field_name": "text_vector", "data_type": "FLOAT_VECTOR", "dim": BGE_DIM},
            {"field_name": "clip_text_vector", "data_type": "FLOAT_VECTOR", "dim": CLIP_DIM},
            {"field_name": "clip_image_vector", "data_type": "FLOAT_VECTOR", "dim": CLIP_DIM},
            {"field_name": "text", "data_type": "VARCHAR", "max_length": 65535},
            {"field_name": "db_id", "data_type": "INT64"},
            {"field_name": "file_name", "data_type": "VARCHAR", "max_length": 512},
            {"field_name": "file_path", "data_type": "VARCHAR", "max_length": 1024},
        ],
    }

    index_params = client.prepare_index_params()
    index_params.add_index(
        field_name="text_vector",
        index_type="IVF_FLAT",
        metric_type="IP",
        params={"nlist": 128},
    )
    index_params.add_index(
        field_name="clip_text_vector",
        index_type="IVF_FLAT",
        metric_type="IP",
        params={"nlist": 128},
    )
    index_params.add_index(
        field_name="clip_image_vector",
        index_type="IVF_FLAT",
        metric_type="IP",
        params={"nlist": 128},
    )

    client.create_collection(
        collection_name=COLLECTION_NAME,
        schema=schema,
        index_params=index_params,
    )

    logger.info(f"Collection '{COLLECTION_NAME}' created successfully")


_client: MilvusClient | None = None


def get_client() -> MilvusClient:
    global _client
    if _client is None:
        from config import MILVUS_URI, MILVUS_TOKEN
        _client = MilvusClient(uri=MILVUS_URI, token=MILVUS_TOKEN)
    return _client


def insert_chunk(
    text: str,
    text_bge_embedding: list[float],
    text_clip_embedding: list[float],
    image_clip_embedding: list[float],
    db_id: int,
    file_name: str,
    file_path: str,
):
    """将单个 chunk（含三个向量）写入 Milvus。"""
    data = [{
        "text_vector": text_bge_embedding,
        "clip_text_vector": text_clip_embedding,
        "clip_image_vector": image_clip_embedding,
        "text": text,
        "db_id": db_id,
        "file_name": file_name,
        "file_path": file_path,
    }]
    get_client().insert(collection_name=COLLECTION_NAME, data=data)
    logger.debug(f"Inserted chunk for file_id={db_id}")


def search(query_embedding: list[float], top_k: int = 5, anns_field: str = "text_vector") -> list[dict]:
    """根据向量检索 Milvus 中的相关 chunk。"""
    results = get_client().search(
        collection_name=COLLECTION_NAME,
        data=[query_embedding],
        limit=top_k,
        anns_field=anns_field,
        output_fields=["text", "db_id", "file_name", "file_path"],
    )
    return results


def delete_by_db_id(db_id: int):
    """按 db_id 删除 Milvus 中的所有记录。"""
    get_client().delete(collection_name=COLLECTION_NAME, filter=f"db_id == {db_id}")
    logger.info(f"Deleted Milvus records for db_id={db_id}")
