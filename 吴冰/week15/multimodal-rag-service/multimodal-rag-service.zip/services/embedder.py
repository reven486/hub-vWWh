import os
import traceback
import logging
import numpy as np

from sentence_transformers import SentenceTransformer
from config import BGE_MODEL_PATH, CLIP_MODEL_PATH, BGE_DIM, CLIP_DIM

logger = logging.getLogger(__name__)

_bge_model = None
_clip_model = None


def get_bge_model() -> SentenceTransformer:
    global _bge_model
    if _bge_model is None:
        logger.info(f"Loading BGE model from {BGE_MODEL_PATH}")
        _bge_model = SentenceTransformer(BGE_MODEL_PATH)
    return _bge_model


def get_clip_model() -> SentenceTransformer:
    global _clip_model
    if _clip_model is None:
        logger.info(f"Loading CLIP model from {CLIP_MODEL_PATH}")
        _clip_model = SentenceTransformer(CLIP_MODEL_PATH, trust_remote_code=True, truncate_dim=CLIP_DIM)
    return _clip_model


def encode_text(text: str) -> tuple[list[float], list[float]]:
    """对纯文本进行 BGE + CLIP 编码。

    返回 (bge_embedding, clip_text_embedding)。
    """
    bge_model = get_bge_model()
    clip_model = get_clip_model()

    try:
        bge_emb = bge_model.encode(text, normalize_embeddings=True)
        bge_emb = list(bge_emb)
    except Exception:
        logger.exception("BGE encoding failed")
        bge_emb = [0.0] * BGE_DIM

    try:
        clip_emb = clip_model.encode(text, normalize_embeddings=True)
        clip_emb = list(clip_emb)
    except Exception:
        logger.exception("CLIP text encoding failed")
        clip_emb = [0.0] * CLIP_DIM

    return bge_emb, clip_emb


def encode_image(image_path: str) -> list[float]:
    """对图片进行 CLIP 编码。

    返回 clip_image_embedding。
    """
    clip_model = get_clip_model()

    if not os.path.exists(image_path):
        logger.warning(f"Image not found: {image_path}")
        return [0.0] * CLIP_DIM

    try:
        logger.info(f"Encoding image: {image_path}")
        emb = clip_model.encode(image_path, normalize_embeddings=True)
        return list(emb)
    except Exception:
        logger.exception("CLIP image encoding failed")
        return [0.0] * CLIP_DIM
