from config import CHUNK_SIZE


def split_text2chunks(text: str, chunk_size: int = CHUNK_SIZE) -> list[str]:
    """将 markdown 文本按行分割为 chunks。

    规则:
    - 跳过空行和参考文献标题
    - 跳过以 [数字] 开头的引用行
    - 尽量将行合并到当前 chunk，直到超过 chunk_size
    """
    lines = text.split("\n")
    chunks = []

    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line == "# References":
            continue
        if len(line) > 2 and line[0] == "[" and line[1].isdigit():
            continue

        if len(line) <= 2:
            continue

        if not chunks or len(chunks[-1]) > chunk_size:
            chunks.append(line)
        else:
            chunks[-1] += "\n" + line

    return chunks
