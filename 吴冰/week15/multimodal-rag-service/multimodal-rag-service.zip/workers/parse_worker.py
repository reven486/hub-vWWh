import os
import glob
import json
import traceback
import logging

from kafka import KafkaConsumer

from config import KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC
from services.pdf_parser import parse_pdf
from services.chunker import split_text2chunks
from services.embedder import encode_text, encode_image
from services.vector_store import insert_chunk
from orm.database import Session
from orm.models import File

logger = logging.getLogger(__name__)


def process_document(file_id: int, file_name: str, file_path: str):
    """处理单个 PDF 文件：解析 → 分块 → 编码 → 入库。"""
    # Step 1: 更新状态为解析中
    with Session() as db:
        record = db.query(File).filter(File.id == file_id).first()
        if record:
            record.filestate = "解析中"
            db.commit()

    # Step 2: MinerU 解析
    try:
        md_path = parse_pdf(file_path)
        logger.info(f"Parsed markdown: {md_path}")
    except Exception:
        logger.exception(f"Failed to parse {file_path}")
        with Session() as db:
            record = db.query(File).filter(File.id == file_id).first()
            if record:
                record.filestate = "解析失败"
                db.commit()
        return

    # Step 3: 读取 markdown 并分块
    md_text = open(md_path, "r", encoding="utf-8").read()
    chunks = split_text2chunks(md_text)
    logger.info(f"Split into {len(chunks)} chunks")

    # Step 4: 编码并写入 Milvus
    md_dir = os.path.dirname(md_path)
    for i, chunk in enumerate(chunks):
        # 提取 chunk 中的图片路径
        image_url = None
        for line in chunk.split("\n"):
            if line.startswith("!["):
                parts = line.split("](")
                if len(parts) >= 2:
                    img_rel = parts[1].rstrip(")")
                    image_url = os.path.join(md_dir, img_rel)
                    break

        # 文本编码
        bge_emb, clip_text_emb = encode_text(chunk)

        # 图片编码（如果有）
        if image_url and os.path.exists(image_url):
            clip_image_emb = encode_image(image_url)
        else:
            clip_image_emb = [0.0] * 1024

        try:
            insert_chunk(
                text=chunk,
                text_bge_embedding=bge_emb,
                text_clip_embedding=clip_text_emb,
                image_clip_embedding=clip_image_emb,
                db_id=file_id,
                file_name=file_name,
                file_path=file_path,
            )
        except Exception:
            logger.exception(f"Failed to insert chunk {i} for file_id={file_id}")

    # Step 5: 更新状态为已解析
    with Session() as db:
        record = db.query(File).filter(File.id == file_id).first()
        if record:
            record.filestate = "已解析"
            db.commit()

    logger.info(f"Document {file_name} processed successfully")


def main():
    """Kafka 消费者主循环。"""
    consumer = KafkaConsumer(
        KAFKA_TOPIC,
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
        enable_auto_commit=True,
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
    )

    logger.info(f"Worker started, listening to topic: {KAFKA_TOPIC}")

    for msg in consumer:
        try:
            value = msg.value
            logger.info(f"Received message: {value}")

            file_id = value["id"]
            file_name = value["file_name"]
            file_path = value["file_path"]

            if not os.path.exists(file_path):
                logger.error(f"File not found: {file_path}")
                continue

            process_document(file_id, file_name, file_path)

        except Exception:
            logger.exception("Error processing message")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
