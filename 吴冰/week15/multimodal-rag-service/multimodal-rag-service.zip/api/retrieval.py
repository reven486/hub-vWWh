import logging
import re

from fastapi import APIRouter

from schemas.retrieval import RetrieveRequest, RetrieveResponse, RetrieveResult
from services.embedder import get_bge_model, get_clip_model
from services.vector_store import search

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/retrieve", tags=["retrieval"])


def _extract_image_urls(text: str) -> list[str]:
    """从 markdown 文本中提取图片 URL。"""
    urls = []
    for line in text.split("\n"):
        if line.startswith("!["):
            m = re.search(r"!\[.*?\]\((.+?)\)", line)
            if m:
                urls.append(m.group(1))
    return urls


@router.post("/", response_model=RetrieveResponse)
def retrieve(req: RetrieveRequest):
    """多模态检索：将查询编码后在 Milvus 中检索相关文本和图片。

    支持三种检索路径：
    - text 模态：BGE text_vector → 文本查文本
    - image 模态：CLIP clip_image_vector → 文本查图片
    - image 模态：CLIP clip_text_vector → 文本查图文混合
    """
    results = []
    seen = set()  # 用于去重 (file_name, text 前 100 字符)

    # 1. 文本检索 (BGE text_vector)
    if "text" in req.modalities:
        bge_model = get_bge_model()
        query_bge_emb = list(bge_model.encode(req.query, normalize_embeddings=True))
        text_results = search(query_bge_emb, top_k=req.top_k, anns_field="text_vector")

        for hit_list in text_results:
            for hit in hit_list:
                entity = hit["entity"]
                key = (entity.get("file_name", ""), entity.get("text", "")[:100])
                if key in seen:
                    continue
                seen.add(key)
                results.append(RetrieveResult(
                    type="text",
                    content=entity.get("text", ""),
                    source_file=entity.get("file_name", ""),
                    score=hit.get("distance", 0.0),
                ))

    # 2. 图片检索 — CLIP image vector (文本查图片)
    if "image" in req.modalities:
        clip_model = get_clip_model()
        query_clip_emb = list(clip_model.encode(req.query, normalize_embeddings=True))

        # 2a. 通过 clip_image_vector 检索匹配的图片
        image_results = search(query_clip_emb, top_k=req.top_k, anns_field="clip_image_vector")
        for hit_list in image_results:
            for hit in hit_list:
                entity = hit["entity"]
                text = entity.get("text", "")
                image_urls = _extract_image_urls(text)
                if not image_urls:
                    continue
                key = (entity.get("file_name", ""), entity.get("text", "")[:100])
                if key in seen:
                    continue
                seen.add(key)
                results.append(RetrieveResult(
                    type="image",
                    image_url=image_urls[0],
                    caption=text[:200],
                    source_file=entity.get("file_name", ""),
                    score=hit.get("distance", 0.0),
                ))

        # 2b. 通过 clip_text_vector 检索图文混合内容
        mixed_results = search(query_clip_emb, top_k=req.top_k, anns_field="clip_text_vector")
        for hit_list in mixed_results:
            for hit in hit_list:
                entity = hit["entity"]
                text = entity.get("text", "")
                image_urls = _extract_image_urls(text)
                if not image_urls:
                    continue
                key = (entity.get("file_name", ""), entity.get("text", "")[:100])
                if key in seen:
                    continue
                seen.add(key)
                results.append(RetrieveResult(
                    type="image",
                    image_url=image_urls[0],
                    caption=text[:200],
                    source_file=entity.get("file_name", ""),
                    score=hit.get("distance", 0.0),
                ))

    return RetrieveResponse(results=results)
