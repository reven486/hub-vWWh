import os
import uuid
import json
import logging

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from sqlalchemy.orm import Session
from kafka import KafkaProducer

from orm.database import get_db
from orm.models import File
from schemas.document import DocumentUploadResponse, DocumentInfo, DocumentStatusResponse
from config import UPLOAD_DIR, KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/documents", tags=["documents"])


def _get_kafka_producer():
    return KafkaProducer(
        bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
    )


@router.post("/upload", response_model=DocumentUploadResponse)
async def upload_document(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """上传 PDF 文档，写入本地并发送 Kafka 消息触发离线解析。"""
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="仅支持 PDF 文件")

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    save_name = str(uuid.uuid4())
    save_path = os.path.join(UPLOAD_DIR, save_name + ".pdf")

    content = await file.read()
    with open(save_path, "wb") as f:
        f.write(content)

    record = File(filename=file.filename, filepath=save_path, filestate="已上传")
    db.add(record)
    db.commit()
    db.refresh(record)

    # 发送 Kafka 消息
    try:
        producer = _get_kafka_producer()
        producer.send(
            KAFKA_TOPIC,
            value={
                "file_name": file.filename,
                "file_path": save_path,
                "id": record.id,
            },
        )
        producer.flush()
        logger.info(f"Sent Kafka message for file_id={record.id}")
    except Exception as e:
        logger.error(f"Failed to send Kafka message: {e}")

    return DocumentUploadResponse(id=record.id, filename=record.filename, filestate=record.filestate)


@router.get("/", response_model=list[DocumentInfo])
def list_documents(db: Session = Depends(get_db)):
    """查询所有已上传文档列表。"""
    files = db.query(File).all()
    return [
        DocumentInfo(
            id=f.id,
            filename=f.filename,
            filepath=f.filepath,
            filestate=f.filestate,
            created_at=f.created_at,
        )
        for f in files
    ]


@router.delete("/{doc_id}")
def delete_document(doc_id: int, db: Session = Depends(get_db)):
    """删除文档及其 Milvus 向量数据。"""
    record = db.query(File).filter(File.id == doc_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="文档不存在")

    # 删除本地文件
    if os.path.exists(record.filepath):
        os.remove(record.filepath)

    # 删除 Milvus 数据
    from services.vector_store import delete_by_db_id
    delete_by_db_id(doc_id)

    # 删除数据库记录
    db.delete(record)
    db.commit()

    return {"message": "删除成功"}


@router.get("/{doc_id}/status", response_model=DocumentStatusResponse)
def get_document_status(doc_id: int, db: Session = Depends(get_db)):
    """查询文档解析状态。"""
    record = db.query(File).filter(File.id == doc_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="文档不存在")

    return DocumentStatusResponse(id=record.id, filename=record.filename, filestate=record.filestate)
