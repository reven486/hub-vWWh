import logging

from fastapi import APIRouter

from schemas.chat import ChatRequest, ChatResponse, SourceInfo
from services.embedder import get_bge_model
from services.vector_store import search
from services.qa_service import generate_answer

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/chat", tags=["chat"])


@router.post("/", response_model=ChatResponse)
def chat(req: ChatRequest):
    """多模态问答：检索相关资料后调用 LLM 生成答案。"""
    # Step 1: 编码查询
    bge_model = get_bge_model()
    query_emb = list(bge_model.encode(req.query, normalize_embeddings=True))

    # Step 2: 检索
    hit_results = search(query_emb, top_k=req.top_k, anns_field="text_vector")

    sources = []
    context_parts = []

    for hit_list in hit_results:
        for hit in hit_list:
            entity = hit["entity"]
            text = entity.get("text", "")
            file_name = entity.get("file_name", "")
            context_parts.append(text)

            # 提取图片来源
            for line in text.split("\n"):
                if line.startswith("!["):
                    parts = line.split("](")
                    img_url = parts[1].rstrip(")") if len(parts) >= 2 else None
                    sources.append(SourceInfo(
                        type="image",
                        file=file_name,
                        url=img_url,
                        content=text[:200],
                    ))
                    break
            else:
                sources.append(SourceInfo(
                    type="text",
                    file=file_name,
                    content=text[:200],
                ))

    # Step 3: 生成答案
    context = "\n\n---\n\n".join(context_parts)
    answer = generate_answer(req.query, context)

    return ChatResponse(answer=answer, sources=sources)
