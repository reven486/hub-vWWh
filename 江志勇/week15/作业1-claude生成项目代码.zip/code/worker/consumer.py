import asyncio
import json
from aiokafka import AIOKafkaConsumer
from elasticsearch import AsyncElasticsearch
from app.core.config import get_settings
from app.core.elasticsearch import get_elasticsearch, init_elasticsearch_index
from app.services.document import DocumentService
from app.services.chunker import ChunkerService
from app.services.embedder import EmbedderService
from app.services.retriever import RetrieverService

settings = get_settings()


async def process_document(message: dict) -> None:
    """处理文档消息"""
    document_id = message["document_id"]
    file_path = message.get("file_path") or message.get("file_url")

    doc_service = DocumentService()
    chunker = ChunkerService()
    embedder = EmbedderService()

    result = await doc_service.parse_document(file_path)
    chunks = chunker.chunk_by_semantic(result["content"], result["images"])

    es = get_elasticsearch()
    await init_elasticsearch_index(es)
    retriever = RetrieverService(es)
    await retriever.store_chunks(document_id, chunks)

    print(f"Document {document_id} processed: {len(chunks)} chunks stored")


async def main():
    es = get_elasticsearch()
    await init_elasticsearch_index(es)

    consumer = AIOKafkaConsumer(
        settings.kafka_topic_upload,
        bootstrap_servers=settings.kafka_bootstrap_servers,
        group_id=settings.kafka_consumer_group,
        value_deserializer=lambda m: json.loads(m.decode("utf-8")),
    )
    await consumer.start()

    try:
        async for msg in consumer:
            try:
                await process_document(msg.value)
            except Exception as e:
                print(f"Error processing message: {e}")
    finally:
        await consumer.stop()
        await es.close()


if __name__ == "__main__":
    asyncio.run(main())