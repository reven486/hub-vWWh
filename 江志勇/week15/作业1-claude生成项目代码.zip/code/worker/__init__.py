from .consumer import main as run_consumer

__all__ = ["run_consumer"]