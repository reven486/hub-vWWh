# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

多模态RAG系统 - 解析上传文件并检索相关内容，通过大模型优化回答。系统支持文档中的图片检索和展示。

## 技术栈

| 组件 | 技术 | 用途 |
|------|------|------|
| Web框架 | FastAPI | ASGI 异步 API |
| 搜索引擎 | Elasticsearch 8.x | 全文检索 + dense_vector 向量搜索 |
| Embedding | Sentence-Transformers | 本地模型生成向量 |
| 文档解析 | mineru | 文件解析 + OCR |
| 缓存 | Redis | 热点数据缓存 |
| 离线队列 | Kafka | 离线上传文件解析 |

## 代码组织

```
.
├── app/
│   ├── __init__.py
│   ├── main.py              # FastAPI 入口， lifespan 管理
│   ├── api/                 # 路由层
│   │   ├── __init__.py
│   │   ├── upload.py        # /upload 接口
│   │   └── query.py         # /query 接口
│   ├── services/            # 业务逻辑层
│   │   ├── __init__.py
│   │   ├── document.py      # 文档解析服务
│   │   ├── chunker.py      # Chunk 划分逻辑
│   │   ├── embedder.py     # Embedding 服务
│   │   ├── retriever.py    # 检索与重排
│   │   └── rag.py          # RAG 回答生成
│   ├── models/              # Pydantic 模型
│   │   ├── __init__.py
│   │   ├── request.py       # 请求模型
│   │   └── response.py     # 响应模型
│   └── core/                # 核心配置
│       ├── __init__.py
│       ├── config.py        # 配置加载
│       ├── elasticsearch.py # ES 客户端
│       ├── redis.py        # Redis 客户端
│       └── kafka.py        # Kafka 生产者
├── worker/
│   ├── __init__.py
│   └── consumer.py          # Kafka 消费者，处理离线解析
├── schemas/                 # 数据库 Schema（ES Mapping）
│   └── document.py
├── .env.example             # 环境变量模板
├── requirements.txt
└── docker-compose.yml      # 基础设施编排
```

**分层原则**：`api/` 层只做路由和验证，业务逻辑下沉到 `services/`。

## 实现建议

### Embedding 模型
推荐使用多语言模型：`paraphrase-multilingual-MiniLM-L12-v2`，兼顾中英文效果。

### Chunk 策略
- 按语义划分，保留上下文完整
- 建议 chunk 大小：512 tokens，重叠：50 tokens
- 图片与对应文本 chunk 关联存储

### 检索流程
1. 用户提问 → Embedding 编码
2. Elasticsearch 多路召回（语义相似度 + BM25）
3. 多路结果融合重排
4. 返回 top-k 相关 chunk（含图片引用）

### RAG 回答流程
1. 收集相关 chunk 和图片信息
2. 构建 prompt（上下文 + 图片 + 用户问题）
3. 调用 Qwen 大模型生成优化回答
4. 返回回答，包含对应图片引用

## API 设计

- `POST /upload` - 离线上传解析接口（Kafka 异步处理）
- `POST /query` - RAG 查询接口（返回答案 + 图片）

## 环境变量

详细配置见 `.env.example`，核心变量：

```
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9200
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
QWEN_API_KEY=xxx
```

## 启动命令

```bash
# 安装依赖
pip install -r requirements.txt

# 启动 FastAPI 服务
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# 启动 Kafka Worker（独立进程）
python -m worker.consumer

# Docker Compose 启动全部基础设施
docker-compose up -d
```

## Elasticsearch Index 设计

```python
# schemas/document.py
mapping = {
    "mappings": {
        "properties": {
            "content": {"type": "text"},           # 文本内容
            "embedding": {                          # 向量字段
                "type": "dense_vector",
                "dims": 384,                        # 与 EMBEDDING_DIM 一致
                "index": True,
                "similarity": "cosine"
            },
            "image_paths": {"type": "keyword[]"},   # 图片路径列表
            "document_id": {"type": "keyword"},
            "chunk_id": {"type": "keyword"},
            "created_at": {"type": "date"}
        }
    }
}
```

## 多模态存储设计

**图片存储**：
- 图片保存到本地 `FILE_STORAGE_PATH`，路径格式：`{document_id}/{chunk_id}_{index}.png`
- ES 存储 `image_paths` 字段指向图片路径

**检索返回**：
```json
{
  "answer": "xxx",
  "chunks": [
    {
      "content": "xxx",
      "image_paths": ["/data/uploads/doc1/chunk0_0.png"]
    }
  ]
}
```

## 测试

```bash
# 安装测试依赖
pip install pytest pytest-asyncio httpx

# 运行测试
pytest tests/ -v

# 运行单个测试
pytest tests/test_retriever.py -v -k test_semantic_search
```

测试文件组织：`tests/` 目录，命名 `test_{module}.py`