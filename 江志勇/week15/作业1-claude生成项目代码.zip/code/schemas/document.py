"""
Elasticsearch Index Mapping for Document Chunks
"""
from app.core.config import get_settings

settings = get_settings()


def get_document_mapping() -> dict:
    """返回文档 chunk 的 ES mapping 定义"""
    return {
        "settings": {
            "index": {
                "number_of_shards": 1,
                "number_of_replicas": 0,
            }
        },
        "mappings": {
            "properties": {
                "content": {
                    "type": "text",
                    "analyzer": "standard",
                },
                "embedding": {
                    "type": "dense_vector",
                    "dims": settings.embedding_dim,
                    "index": True,
                    "similarity": "cosine",
                },
                "image_paths": {
                    "type": "keyword",
                },
                "document_id": {
                    "type": "keyword",
                },
                "chunk_id": {
                    "type": "keyword",
                },
                "created_at": {
                    "type": "date",
                },
            }
        },
    }


def get_document_index_name() -> str:
    """返回索引名称"""
    return settings.elasticsearch_index