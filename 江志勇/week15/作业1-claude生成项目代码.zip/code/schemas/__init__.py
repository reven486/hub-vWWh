from .document import get_document_mapping, get_document_index_name

__all__ = ["get_document_mapping", "get_document_index_name"]