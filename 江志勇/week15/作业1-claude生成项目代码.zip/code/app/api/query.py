from fastapi import APIRouter
from elasticsearch import AsyncElasticsearch
from app.models.request import QueryRequest
from app.models.response import QueryResponse, ChunkResponse
from app.services.retriever import RetrieverService
from app.services.rag import RAGService

router = APIRouter(prefix="/query", tags=["RAG查询"])


@router.post("", response_model=QueryResponse)
async def query(question: QueryRequest, es: AsyncElasticsearch):
    """RAG查询接口"""
    retriever = RetrieverService(es)
    rag = RAGService()

    chunks = await retriever.semantic_search(question.question)
    chunks = chunks[:question.top_k]

    answer = await rag.generate_answer(question.question, chunks)

    return QueryResponse(
        answer=answer,
        chunks=[
            ChunkResponse(
                chunk_id=c["chunk_id"],
                content=c["content"],
                image_paths=c.get("image_paths", []),
                score=c["score"],
            )
            for c in chunks
        ],
        sources=list(set(c["chunk_id"] for c in chunks)),
    )