import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException
from app.models.request import UploadRequest
from app.models.response import UploadResponse
from app.core.kafka import get_kafka_producer
from app.core.config import get_settings

router = APIRouter(prefix="/upload", tags=["文档上传"])
settings = get_settings()


@router.post("", response_model=UploadResponse)
async def upload_document(file: UploadFile = File(...)):
    """离线上传解析接口，异步处理"""
    if file.size and file.size > settings.file_max_size_mb * 1024 * 1024:
        raise HTTPException(status_code=400, detail=f"文件大小超过 {settings.file_max_size_mb}MB 限制")

    document_id = str(uuid.uuid4())

    file_path = f"{settings.file_storage_path}/{document_id}_{file.filename}"
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)

    producer = await get_kafka_producer()
    await producer.send_and_wait(
        settings.kafka_topic_upload,
        value=str({
            "document_id": document_id,
            "file_path": file_path,
        }),
        partition=0,
    )

    return UploadResponse(document_id=document_id, status="queued", message="文档已提交处理")


@router.post("/url", response_model=UploadResponse)
async def upload_by_url(request: UploadRequest):
    """通过URL上传文档"""
    document_id = str(uuid.uuid4())

    producer = await get_kafka_producer()
    await producer.send_and_wait(
        settings.kafka_topic_upload,
        value=str({
            "document_id": document_id,
            "file_url": request.file_url,
        }),
        partition=0,
    )

    return UploadResponse(document_id=document_id, status="queued", message="文档已提交处理")