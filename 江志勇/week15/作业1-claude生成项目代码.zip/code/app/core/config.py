from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # Elasticsearch
    elasticsearch_host: str = "localhost"
    elasticsearch_port: int = 9200
    elasticsearch_index: str = "multimodal_rag"
    elasticsearch_user: str = ""
    elasticsearch_password: str = ""

    # Redis
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: str = ""

    # Kafka
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_topic_upload: str = "document_upload"
    kafka_topic_parsed: str = "document_parsed"
    kafka_consumer_group: str = "rag_worker"

    # mineru
    mineru_model_path: str = "/models/mineru"
    mineru_use_gpu: bool = True

    # Embedding
    embedding_model: str = "paraphrase-multilingual-MiniLM-L12-v2"
    embedding_device: str = "cuda"
    embedding_dim: int = 384

    # Chunk
    chunk_size: int = 512
    chunk_overlap: int = 50

    # Qwen
    qwen_api_key: str = ""
    qwen_model_name: str = "qwen-turbo"
    qwen_api_base: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"

    # File storage
    file_storage_path: str = "/data/uploads"
    file_max_size_mb: int = 100

    # RAG
    rag_top_k: int = 10
    rag_rerank_model: str = "baai/bge-reranker-base"
    rag_rerank_top_k: int = 3

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()