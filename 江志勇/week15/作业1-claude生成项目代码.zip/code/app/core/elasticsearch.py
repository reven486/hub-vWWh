from elasticsearch import AsyncElasticsearch
from app.core.config import get_settings

settings = get_settings()


def get_elasticsearch() -> AsyncElasticsearch:
    es = AsyncElasticsearch(
        hosts=[f"http://{settings.elasticsearch_host}:{settings.elasticsearch_port}"],
        basic_auth=(
            settings.elasticsearch_user,
            settings.elasticsearch_password,
        ) if settings.elasticsearch_user else None,
    )
    return es


async def init_elasticsearch_index(es: AsyncElasticsearch) -> None:
    """创建 ES Index（如果不存在）"""
    index_exists = await es.indices.exists(index=settings.elasticsearch_index)
    if not index_exists:
        await es.indices.create(
            index=settings.elasticsearch_index,
            body={
                "settings": {
                    "index": {
                        "number_of_shards": 1,
                        "number_of_replicas": 0,
                    }
                },
                "mappings": {
                    "properties": {
                        "content": {"type": "text"},
                        "embedding": {
                            "type": "dense_vector",
                            "dims": settings.embedding_dim,
                            "index": True,
                            "similarity": "cosine",
                        },
                        "image_paths": {"type": "keyword"},
                        "document_id": {"type": "keyword"},
                        "chunk_id": {"type": "keyword"},
                        "created_at": {"type": "date"},
                    }
                },
            },
        )