import dashscope
from app.core.config import get_settings

settings = get_settings()
dashscope.api_key = settings.qwen_api_key


class RAGService:
    def __init__(self):
        self.model_name = settings.qwen_model_name

    async def generate_answer(self, question: str, chunks: list[dict]) -> str:
        """调用 Qwen 生成回答"""
        context_parts = []
        for chunk in chunks:
            context_parts.append(f"【上下文】\n{chunk['content']}")
            if chunk.get("image_paths"):
                context_parts.append(f"【相关图片】{', '.join(chunk['image_paths'])}")

        context = "\n\n".join(context_parts)

        prompt = f"""你是一个专业的知识库问答助手。请根据提供的上下文内容回答用户问题。

如果上下文中包含相关图片，请在回答中提及这些图片。

【上下文】
{context}

【用户问题】
{question}

请给出准确、详细的回答："""

        response = dashscope.Generation.call(
            model=self.model_name,
            prompt=prompt,
            max_tokens=1000,
        )

        if response.status_code == 200:
            return response.output.choices[0].text
        else:
            return f"抱歉，无法生成回答：{response.message}"