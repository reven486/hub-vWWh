from typing import Any
from app.core.config import get_settings

settings = get_settings()


class ChunkerService:
    def __init__(self):
        self.chunk_size = settings.chunk_size
        self.chunk_overlap = settings.chunk_overlap

    def chunk_by_semantic(self, content: str, images: list[dict]) -> list[dict[str, Any]]:
        """按语义划分chunk，保持上下文完整"""
        chunks = []
        lines = content.split("\n")
        current_chunk = []
        current_size = 0
        image_map = {}

        for img in images:
            img_index = img.get("index", 0)
            image_map[img_index] = img.get("path", "")

        for i, line in enumerate(lines):
            line_size = len(line)
            if current_size + line_size > self.chunk_size and current_chunk:
                chunk_content = "\n".join(current_chunk)
                chunk_images = [
                    image_map[idx] for idx in image_map
                    if idx in range(len(chunks) * self.chunk_size // settings.chunk_size,
                                   (len(chunks) + 1) * self.chunk_size // settings.chunk_size)
                ]

                chunks.append({
                    "content": chunk_content,
                    "image_paths": chunk_images,
                })
                current_chunk = current_chunk[-self.chunk_overlap:]
                current_size = sum(len(l) for l in current_chunk)

            current_chunk.append(line)
            current_size += line_size

        if current_chunk:
            chunks.append({
                "content": "\n".join(current_chunk),
                "image_paths": [],
            })

        return chunks