from sentence_transformers import SentenceTransformer
from app.core.config import get_settings

settings = get_settings()

_model = None


def get_embedder() -> SentenceTransformer:
    global _model
    if _model is None:
        _model = SentenceTransformer(settings.embedding_model, device=settings.embedding_device)
    return _model


class EmbedderService:
    def __init__(self):
        self.model = get_embedder()
        self.dimension = settings.embedding_dim

    def encode(self, texts: list[str]) -> list[list[float]]:
        """将文本编码为向量"""
        embeddings = self.model.encode(texts, normalize_embeddings=True)
        return embeddings.tolist()