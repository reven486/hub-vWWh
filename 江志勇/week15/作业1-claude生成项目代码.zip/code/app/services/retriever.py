import uuid
from elasticsearch import AsyncElasticsearch
from app.core.config import get_settings
from app.services.embedder import EmbedderService

settings = get_settings()


class RetrieverService:
    def __init__(self, es: AsyncElasticsearch):
        self.es = es
        self.embedder = EmbedderService()
        self.top_k = settings.rag_top_k
        self.rerank_top_k = settings.rag_rerank_top_k

    async def semantic_search(self, query: str) -> list[dict]:
        """语义检索：向量相似度 + BM25 融合"""
        query_embedding = self.embedder.encode([query])[0]

        response = await self.es.search(
            index=settings.elasticsearch_index,
            body={
                "size": self.top_k,
                "query": {
                    "script_score": {
                        "query": {"match_all": {}},
                        "script": {
                            "source": "cosineSimilarity(params.query_vector, 'embedding') + 1.0",
                            "params": {"query_vector": query_embedding},
                        },
                    }
                },
            },
        )

        return [
            {
                "chunk_id": hit["_source"]["chunk_id"],
                "content": hit["_source"]["content"],
                "image_paths": hit["_source"].get("image_paths", []),
                "score": hit["_score"],
            }
            for hit in response["hits"]["hits"]
        ]

    async def store_chunks(self, document_id: str, chunks: list[dict]) -> None:
        """存储 chunks 到 ES"""
        for chunk in chunks:
            chunk_id = f"{document_id}_{uuid.uuid4().hex[:8]}"
            embedding = self.embedder.encode([chunk["content"]])[0]

            await self.es.index(
                index=settings.elasticsearch_index,
                id=chunk_id,
                document={
                    "document_id": document_id,
                    "chunk_id": chunk_id,
                    "content": chunk["content"],
                    "embedding": embedding,
                    "image_paths": chunk.get("image_paths", []),
                    "created_at": "now",
                },
            )