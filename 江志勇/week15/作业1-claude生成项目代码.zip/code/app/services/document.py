import uuid
import os
from typing import Any
from mineru import init_env, process_pdf
from app.core.config import get_settings

settings = get_settings()


class DocumentService:
    def __init__(self):
        init_env(device='cuda' if settings.mineru_use_gpu else 'cpu')

    async def parse_document(self, file_path: str) -> dict[str, Any]:
        """解析文档，返回结构化内容和图片"""
        doc_id = str(uuid.uuid4())
        output_dir = os.path.join(settings.file_storage_path, doc_id)
        os.makedirs(output_dir, exist_ok=True)

        result = process_pdf(
            pdf_path=file_path,
            output_dir=output_dir,
            lang="ch",
        )

        return {
            "document_id": doc_id,
            "content": result.get("content", ""),
            "images": result.get("images", []),
            "output_dir": output_dir,
        }