from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from elasticsearch import AsyncElasticsearch
from app.api import upload_router, query_router
from app.core.elasticsearch import get_elasticsearch, init_elasticsearch_index
from app.core.redis import close_redis
from app.core.kafka import close_kafka_producer
from app.core.config import get_settings
from app.models.response import HealthResponse

settings = get_settings()
es_client: AsyncElasticsearch | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global es_client
    es_client = get_elasticsearch()
    await init_elasticsearch_index(es_client)
    yield
    if es_client:
        await es_client.close()
    await close_redis()
    await close_kafka_producer()


app = FastAPI(
    title="多模态RAG系统",
    description="解析文档、检索内容、大模型优化回答",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload_router)
app.include_router(query_router)


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """健康检查"""
    es_ok = False
    try:
        await es_client.ping()
        es_ok = True
    except Exception:
        pass

    return HealthResponse(
        status="ok" if es_ok else "degraded",
        elasticsearch=es_ok,
        redis=True,
        kafka=True,
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)