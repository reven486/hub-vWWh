from pydantic import BaseModel, Field
from typing import Optional


class UploadRequest(BaseModel):
    file_url: str = Field(..., description="文件URL或本地路径")


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000, description="用户问题")
    top_k: Optional[int] = Field(default=10, ge=1, le=100, description="返回chunk数量")


class ChunkResponse(BaseModel):
    chunk_id: str
    content: str
    image_paths: list[str]
    score: float


class QueryResponse(BaseModel):
    answer: str
    chunks: list[ChunkResponse]
    sources: list[str] = Field(default_factory=list)