from pydantic import BaseModel, Field
from typing import Optional


class UploadResponse(BaseModel):
    document_id: str
    status: str = "queued"
    message: str = "文档已提交处理"


class HealthResponse(BaseModel):
    status: str
    elasticsearch: bool
    redis: bool
    kafka: bool