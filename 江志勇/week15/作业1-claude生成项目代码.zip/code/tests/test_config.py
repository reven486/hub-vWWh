import pytest


def test_chunk_size_config():
    """测试 chunk 大小配置"""
    from app.core.config import get_settings
    settings = get_settings()
    assert settings.chunk_size == 512
    assert settings.chunk_overlap == 50


def test_rag_config():
    """测试 RAG 配置"""
    from app.core.config import get_settings
    settings = get_settings()
    assert settings.rag_top_k == 10
    assert settings.rag_rerank_top_k == 3


def test_embedding_dim():
    """测试 embedding 维度"""
    from app.core.config import get_settings
    settings = get_settings()
    assert settings.embedding_dim == 384