import pytest
from app.services.chunker import ChunkerService


@pytest.fixture
def chunker():
    return ChunkerService()


def test_chunk_by_semantic(chunker):
    """测试语义分块"""
    content = "\n".join([f"段落{i}" for i in range(10)])
    images = [{"index": i, "path": f"/img/{i}.png"} for i in range(5)]

    chunks = chunker.chunk_by_semantic(content, images)

    assert len(chunks) > 0
    assert all("content" in c for c in chunks)
    assert all("image_paths" in c for c in chunks)


def test_chunk_content_not_empty(chunker):
    """测试 chunk 内容不为空"""
    content = "这是一段测试内容" * 100
    chunks = chunker.chunk_by_semantic(content, [])

    assert all(c["content"] for c in chunks)