import pytest


@pytest.mark.asyncio
async def test_semantic_search():
    """测试语义检索"""
    from app.services.retriever import RetrieverService

    retriever = RetrieverService(es=None)
    results = await retriever.semantic_search("测试问题")

    assert isinstance(results, list)


@pytest.mark.asyncio
async def test_store_chunks():
    """测试存储 chunks"""
    from app.services.retriever import RetrieverService

    retriever = RetrieverService(es=None)
    chunks = [
        {"content": "测试内容1", "image_paths": []},
        {"content": "测试内容2", "image_paths": ["/img/test.png"]},
    ]

    await retriever.store_chunks("doc_123", chunks)