from typing import List, Optional, Tuple

from loguru import logger

from models.chunk import Chunk, ChunkRetrieveResult


class VectorDB:
    def __init__(
        self,
        host: str = "localhost",
        port: int = 19530,
        collection_name: str = "multimodal_chunks",
    ):
        self.host = host
        self.port = port
        self.collection_name = collection_name
        self.collection = None
        self._mock_mode = False
        self._chunks = []  # In-memory storage for mock mode
        self._init_collection()

    def _init_collection(self):
        try:
            from pymilvus import connections, Collection, CollectionSchema, FieldSchema, DataType
            connections.connect(uri=f"http://{self.host}:{self.port}")
            fields = [
                FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
                FieldSchema(name="document_id", dtype=DataType.INT64),
                FieldSchema(name="chunk_type", dtype=DataType.VARCHAR, max_length=10),
                FieldSchema(name="content", dtype=DataType.VARCHAR, max_length=65535),
                FieldSchema(name="page_number", dtype=DataType.INT64),
                FieldSchema(name="chunk_index", dtype=DataType.INT64),
                FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=1024),
            ]
            schema = CollectionSchema(fields=fields, description="Multimodal RAG chunks")
            self.collection = Collection(name=self.collection_name, schema=schema)
            self.collection.create_index(field_name="embedding", index_type="HNSW", params={"M": 16, "efConstruction": 200})
            logger.info("Milvus connected successfully")
        except Exception as e:
            logger.warning(f"Milvus not available, using mock mode: {e}")
            self._mock_mode = True
            self.collection = None

    def insert_text_chunk(
        self, document_id: int, page_number: int, chunk_index: int, content: str, embedding: List[float]
    ) -> str:
        if self._mock_mode:
            chunk_id = len(self._chunks) + 1
            self._chunks.append({
                "id": chunk_id,
                "document_id": document_id,
                "chunk_type": "text",
                "content": content,
                "page_number": page_number,
                "chunk_index": chunk_index,
                "embedding": embedding,
            })
            logger.info(f"Mock: inserted text chunk {chunk_id}")
            return str(chunk_id)

        data = [
            {
                "document_id": document_id,
                "chunk_type": "text",
                "content": content,
                "page_number": page_number,
                "chunk_index": chunk_index,
                "embedding": embedding,
            }
        ]
        result = self.collection.insert(data)
        self.collection.flush()
        return str(result[0]["id"])

    def insert_image_chunk(
        self, document_id: int, page_number: int, chunk_index: int, image_path: str, embedding: List[float]
    ) -> str:
        if self._mock_mode:
            chunk_id = len(self._chunks) + 1
            self._chunks.append({
                "id": chunk_id,
                "document_id": document_id,
                "chunk_type": "image",
                "content": image_path,
                "page_number": page_number,
                "chunk_index": chunk_index,
                "embedding": embedding,
            })
            logger.info(f"Mock: inserted image chunk {chunk_id}")
            return str(chunk_id)

        data = [
            {
                "document_id": document_id,
                "chunk_type": "image",
                "content": image_path,
                "page_number": page_number,
                "chunk_index": chunk_index,
                "embedding": embedding,
            }
        ]
        result = self.collection.insert(data)
        self.collection.flush()
        return str(result[0]["id"])

    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        dot = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5
        return dot / (norm1 * norm2) if norm1 and norm2 else 0.0

    def search_text(self, query_embedding: List[float], top_k: int = 5) -> List[dict]:
        if self._mock_mode:
            scored = []
            for chunk in self._chunks:
                if chunk["chunk_type"] == "text":
                    sim = self._cosine_similarity(query_embedding, chunk["embedding"])
                    scored.append({**chunk, "distance": 1 - sim})
            scored.sort(key=lambda x: x["distance"])
            return scored[:top_k]

        search_params = {"metric_type": "COSINE", "params": {"ef": 200}}
        results = self.collection.search(
            data=[query_embedding],
            anns_field="embedding",
            param=search_params,
            limit=top_k,
            output_fields=["document_id", "chunk_type", "content", "page_number", "chunk_index"],
        )
        return results[0] if results else []

    def search_image(self, query_embedding: List[float], top_k: int = 5) -> List[dict]:
        if self._mock_mode:
            scored = []
            for chunk in self._chunks:
                if chunk["chunk_type"] == "image":
                    sim = self._cosine_similarity(query_embedding, chunk["embedding"])
                    scored.append({**chunk, "distance": 1 - sim})
            scored.sort(key=lambda x: x["distance"])
            return scored[:top_k]
        return self.search_text(query_embedding, top_k)

    def delete_by_document_id(self, document_id: int) -> bool:
        if self._mock_mode:
            self._chunks = [c for c in self._chunks if c["document_id"] != document_id]
            logger.info(f"Mock: deleted chunks for document {document_id}")
            return True

        try:
            expr = f"document_id == {document_id}"
            self.collection.delete(expr)
            self.collection.flush()
            logger.info(f"Deleted chunks for document {document_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete chunks for document {document_id}: {e}")
            return False

    def close(self):
        if not self._mock_mode:
            try:
                from pymilvus import connections
                connections.disconnect()
            except Exception:
                pass