from datetime import datetime
from typing import List, Optional

from loguru import logger
from sqlalchemy import Column, DateTime, Enum, Integer, String, Text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from models.chunk import Chunk, ChunkType
from models.document import Document, DocumentCreate, DocumentStatus

Base = declarative_base()


class DocumentModel(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, autoincrement=True)
    knowledge_base_id = Column(Integer, nullable=False, index=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(512), nullable=False)
    status = Column(Enum(DocumentStatus), default=DocumentStatus.PENDING)
    page_count = Column(Integer, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class ChunkModel(Base):
    __tablename__ = "chunks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(Integer, nullable=False, index=True)
    chunk_type = Column(Enum(ChunkType), nullable=False)
    content = Column(Text, nullable=False)
    page_number = Column(Integer, nullable=False)
    chunk_index = Column(Integer, nullable=False)
    vector_id = Column(String(64), nullable=True)
    metadata_json = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.now)


class MetadataDB:
    def __init__(self, database_url: str = "sqlite+aiosqlite:///./data/metadata.db"):
        self.async_engine = create_async_engine(database_url, echo=False)
        self.async_session = sessionmaker(self.async_engine, class_=AsyncSession, expire_on_commit=False)

    async def init_db(self):
        async with self.async_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database initialized")

    async def create_document(self, doc: DocumentCreate) -> Document:
        async with self.async_session() as session:
            model = DocumentModel(
                knowledge_base_id=doc.knowledge_base_id,
                filename=doc.filename,
                file_path=doc.file_path,
                status=DocumentStatus.PENDING,
            )
            session.add(model)
            await session.commit()
            await session.refresh(model)
            return Document(
                id=model.id,
                knowledge_base_id=model.knowledge_base_id,
                filename=model.filename,
                file_path=model.file_path,
                status=model.status,
                page_count=model.page_count,
                error_message=model.error_message,
                created_at=model.created_at,
                updated_at=model.updated_at,
            )

    async def get_document(self, document_id: int) -> Optional[Document]:
        async with self.async_session() as session:
            result = await session.get(DocumentModel, document_id)
            if not result:
                return None
            return Document(
                id=result.id,
                knowledge_base_id=result.knowledge_base_id,
                filename=result.filename,
                file_path=result.file_path,
                status=result.status,
                page_count=result.page_count,
                error_message=result.error_message,
                created_at=result.created_at,
                updated_at=result.updated_at,
            )

    async def update_document_status(
        self, document_id: int, status: DocumentStatus, page_count: Optional[int] = None, error_message: Optional[str] = None
    ):
        async with self.async_session() as session:
            result = await session.get(DocumentModel, document_id)
            if result:
                result.status = status
                if page_count is not None:
                    result.page_count = page_count
                if error_message:
                    result.error_message = error_message
                result.updated_at = datetime.now()
                await session.commit()

    async def list_documents(self, knowledge_base_id: Optional[int] = None, status: Optional[DocumentStatus] = None) -> List[Document]:
        async with self.async_session() as session:
            from sqlalchemy import select
            query = select(DocumentModel)
            if knowledge_base_id:
                query = query.where(DocumentModel.knowledge_base_id == knowledge_base_id)
            if status:
                query = query.where(DocumentModel.status == status)
            result = await session.execute(query)
            results = result.scalars().all()
            return [Document.model_validate(r) for r in results]

    async def create_chunk(self, chunk_create: "ChunkCreate") -> Chunk:
        async with self.async_session() as session:
            import json
            model = ChunkModel(
                document_id=chunk_create.document_id,
                chunk_type=chunk_create.chunk_type,
                content=chunk_create.content,
                page_number=chunk_create.page_number,
                chunk_index=chunk_create.chunk_index,
                metadata_json=json.dumps(chunk_create.metadata) if chunk_create.metadata else None,
            )
            session.add(model)
            await session.commit()
            await session.refresh(model)
            return Chunk(
                id=model.id,
                document_id=model.document_id,
                chunk_type=model.chunk_type,
                content=model.content,
                page_number=model.page_number,
                chunk_index=model.chunk_index,
                vector_id=model.vector_id,
                metadata=json.loads(model.metadata_json) if model.metadata_json else {},
                created_at=model.created_at,
            )

    async def update_chunk_vector_id(self, chunk_id: int, vector_id: str):
        async with self.async_session() as session:
            result = await session.get(ChunkModel, chunk_id)
            if result:
                result.vector_id = vector_id
                await session.commit()

    async def get_chunks_by_document(self, document_id: int) -> List[Chunk]:
        async with self.async_session() as session:
            import json
            from sqlalchemy import select
            query = select(ChunkModel).where(ChunkModel.document_id == document_id)
            result = await session.execute(query)
            results = result.scalars().all()
            return [
                Chunk(
                    id=r.id,
                    document_id=r.document_id,
                    chunk_type=r.chunk_type,
                    content=r.content,
                    page_number=r.page_number,
                    chunk_index=r.chunk_index,
                    vector_id=r.vector_id,
                    metadata=json.loads(r.metadata_json) if r.metadata_json else {},
                    created_at=r.created_at,
                )
                for r in results
            ]

    async def close(self):
        await self.async_engine.dispose()