import hashlib
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional

import aiofiles
from loguru import logger


class FileStorage:
    def __init__(self, base_dir: str = "./data/files"):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _generate_path(self, knowledge_base_id: int, filename: str) -> Path:
        date_str = datetime.now().strftime("%Y%m%d")
        hash_name = hashlib.md5(filename.encode()).hexdigest()[:8]
        subdir = self.base_dir / f"kb_{knowledge_base_id}" / date_str
        subdir.mkdir(parents=True, exist_ok=True)
        return subdir / f"{hash_name}_{filename}"

    async def save(self, content: bytes, knowledge_base_id: int, filename: str) -> str:
        path = self._generate_path(knowledge_base_id, filename)
        async with aiofiles.open(path, "wb") as f:
            await f.write(content)
        logger.info(f"File saved: {path}")
        return str(path)

    def delete(self, file_path: str) -> bool:
        try:
            Path(file_path).unlink(missing_ok=True)
            logger.info(f"File deleted: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete file {file_path}: {e}")
            return False

    def get_url(self, file_path: str, base_url: Optional[str] = None) -> str:
        if base_url:
            return f"{base_url}/files/{Path(file_path).name}"
        return file_path


class LocalFileStorage(FileStorage):
    pass


class OSSFileStorage(FileStorage):
    def __init__(self, access_key: str, secret_key: str, endpoint: str, bucket: str):
        super().__init__()
        self.access_key = access_key
        self.secret_key = secret_key
        self.endpoint = endpoint
        self.bucket = bucket

    async def save(self, content: bytes, knowledge_base_id: int, filename: str) -> str:
        import oss2
        path = self._generate_path(knowledge_base_id, filename)
        auth = oss2.Auth(self.access_key, self.secret_key)
        bucket = oss2.Bucket(auth, self.endpoint, self.bucket)
        bucket.put_object(str(path), content)
        logger.info(f"File uploaded to OSS: {path}")
        return str(path)