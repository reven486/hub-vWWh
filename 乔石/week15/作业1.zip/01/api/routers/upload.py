import os
import uuid
from typing import Optional

from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from loguru import logger

from models.document import DocumentCreate, DocumentResponse, DocumentStatus
from storage.file_storage import FileStorage
from storage.metadata_db import MetadataDB
from worker.consumer import MessageProducer

router = APIRouter()

file_storage = FileStorage(base_dir="./data/files")
metadata_db = MetadataDB()
message_producer: Optional[MessageProducer] = None


async def get_producer() -> MessageProducer:
    global message_producer
    if message_producer is None:
        message_producer = MessageProducer()
        await message_producer.start()
    return message_producer


@router.post("/upload/document", response_model=DocumentResponse)
async def upload_document(
    knowledge_base_id: int = Query(..., description="Knowledge base ID"),
    file: UploadFile = File(...),
):
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")

    content = await file.read()
    file_path = await file_storage.save(content, knowledge_base_id, file.filename)

    doc_create = DocumentCreate(
        knowledge_base_id=knowledge_base_id,
        filename=file.filename,
        file_path=file_path,
    )
    document = await metadata_db.create_document(doc_create)

    producer = await get_producer()
    task_id = str(uuid.uuid4())
    await producer.send(
        topic="document_parse",
        value={
            "document_id": document.id,
            "task_id": task_id,
            "file_path": file_path,
            "knowledge_base_id": knowledge_base_id,
        },
        key=str(document.id),
    )

    logger.info(f"Document {document.id} uploaded, task {task_id} queued")

    return DocumentResponse(
        id=document.id,
        task_id=task_id,
        status=document.status,
        message="Document uploaded successfully, processing started",
    )


@router.get("/document/{document_id}")
async def get_document_status(document_id: int):
    document = await metadata_db.get_document(document_id)
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document


@router.get("/documents")
async def list_documents(
    knowledge_base_id: Optional[int] = None,
    status: Optional[str] = None,
):
    status_enum = DocumentStatus(status) if status else None
    documents = await metadata_db.list_documents(knowledge_base_id, status_enum)
    return {"documents": documents, "total": len(documents)}