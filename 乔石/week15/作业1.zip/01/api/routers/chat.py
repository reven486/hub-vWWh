from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from loguru import logger

from models.chunk import ChunkRetrieveResult
from services.embedder import Embedder
from services.qa import QAService
from services.retriever import RetrievalResult, Retriever
from storage.metadata_db import MetadataDB
from storage.vector_db import VectorDB

router = APIRouter()

vector_db = VectorDB()
embedder = Embedder()
retriever = Retriever(vector_db, embedder.text_embedder, embedder.clip_model)
qa_service = QAService()
metadata_db = MetadataDB()


class ChatRequest(BaseModel):
    query: str = Field(..., description="User's question")
    knowledge_base_id: int = Field(..., description="Knowledge base ID")
    top_k: int = Field(default=5, description="Number of results to retrieve")


class SourceReference(BaseModel):
    page: int
    filename: str
    score: float


class ChatResponse(BaseModel):
    answer: str
    sources: list[SourceReference]


@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    if not request.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    try:
        retrieval_result = await retriever.retrieve(
            query=request.query,
            knowledge_base_id=request.knowledge_base_id,
            top_k=request.top_k,
        )

        answer = await qa_service.generate(
            query=request.query,
            text_chunks=retrieval_result.text_chunks,
            image_chunks=retrieval_result.image_chunks,
        )

        sources = []
        for result in retrieval_result.text_chunks:
            sources.append(
                SourceReference(
                    page=result.chunk.page_number,
                    filename=result.document_filename,
                    score=result.score,
                )
            )
        for result in retrieval_result.image_chunks:
            if any(s.page == result.chunk.page_number and s.filename == result.document_filename for s in sources):
                continue
            sources.append(
                SourceReference(
                    page=result.chunk.page_number,
                    filename=result.document_filename,
                    score=result.score,
                )
            )

        logger.info(f"Chat request processed, {len(sources)} sources found")

        return ChatResponse(answer=answer, sources=sources)

    except Exception as e:
        logger.error(f"Chat request failed: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process chat: {str(e)}")


@router.get("/chat/history")
async def get_chat_history(
    knowledge_base_id: int = Query(...),
    limit: int = Query(default=20, le=100),
):
    return {"history": [], "message": "Chat history feature not yet implemented"}