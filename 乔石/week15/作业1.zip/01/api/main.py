import os

from fastapi import FastAPI, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from api.routers import chat, upload
from storage.metadata_db import MetadataDB

os.makedirs("./data", exist_ok=True)

app = FastAPI(
    title="Multimodal RAG API",
    description="API for multimodal retrieval-augmented generation from PDF documents",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload.router, prefix="/api", tags=["upload"])
app.include_router(chat.router, prefix="/api", tags=["chat"])


@app.on_event("startup")
async def startup_event():
    db = MetadataDB()
    await db.init_db()
    logger.info("API server started")


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)