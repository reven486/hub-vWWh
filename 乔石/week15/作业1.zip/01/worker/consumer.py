import asyncio
from typing import Optional

from aiokafka import AIOKafkaConsumer
from loguru import logger


class KafkaConsumer:
    def __init__(self, bootstrap_servers: str = "localhost:9092", topic: str = "document_parse", group_id: str = "document_worker"):
        self.bootstrap_servers = bootstrap_servers
        self.topic = topic
        self.group_id = group_id
        self.consumer: Optional[AIOKafkaConsumer] = None

    async def start(self):
        self.consumer = AIOKafkaConsumer(
            self.topic,
            bootstrap_servers=self.bootstrap_servers,
            group_id=self.group_id,
            auto_offset_reset="earliest",
            enable_auto_commit=True,
        )
        await self.consumer.start()
        logger.info(f"Kafka consumer started, listening on topic: {self.topic}")

    async def consume(self) -> dict:
        if not self.consumer:
            await self.start()
        async for message in self.consumer:
            try:
                import json
                data = json.loads(message.value.decode())
                logger.info(f"Received message: {data}")
                yield data
            except Exception as e:
                logger.error(f"Failed to parse message: {e}")

    async def stop(self):
        if self.consumer:
            await self.consumer.stop()
            logger.info("Kafka consumer stopped")


class MessageProducer:
    def __init__(self, bootstrap_servers: str = "localhost:9092"):
        self.bootstrap_servers = bootstrap_servers
        self.producer = None

    async def start(self):
        from aiokafka import AIOKafkaProducer
        self.producer = AIOKafkaProducer(bootstrap_servers=self.bootstrap_servers)
        await self.producer.start()
        logger.info("Kafka producer started")

    async def send(self, topic: str, value: dict, key: Optional[str] = None):
        if not self.producer:
            await self.start()
        import json
        await self.producer.send_and_wait(
            topic,
            value=json.dumps(value).encode("utf-8"),
            key=key.encode("utf-8") if key else None,
        )
        logger.info(f"Message sent to topic {topic}: {value}")

    async def stop(self):
        if self.producer:
            await self.producer.stop()
            logger.info("Kafka producer stopped")