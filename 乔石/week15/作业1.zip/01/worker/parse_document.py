import asyncio
import json
from datetime import datetime
from pathlib import Path

from loguru import logger

from services.embedder import Embedder
from services.pdf_parser import PDFParser
from storage.metadata_db import MetadataDB
from storage.vector_db import VectorDB
from worker.consumer import KafkaConsumer


class DocumentParserWorker:
    def __init__(
        self,
        kafka_bootstrap: str = "localhost:9092",
        parse_topic: str = "document_parse",
        milvus_host: str = "localhost",
        milvus_port: int = 19530,
        db_url: str = "sqlite+aiosqlite:///./data/metadata.db",
    ):
        self.consumer = KafkaConsumer(bootstrap_servers=kafka_bootstrap, topic=parse_topic)
        self.pdf_parser = PDFParser()
        self.embedder = Embedder()
        self.vector_db = VectorDB(host=milvus_host, port=milvus_port)
        self.metadata_db = MetadataDB(database_url=db_url)

    async def start(self):
        await self.metadata_db.init_db()
        await self.consumer.start()
        logger.info("Document parser worker started")

        try:
            async for message in self.consumer.consume():
                await self.process_document(message)
        except asyncio.CancelledError:
            logger.info("Worker cancelled")
        finally:
            await self.consumer.stop()

    async def process_document(self, message: dict):
        document_id = message.get("document_id")
        file_path = message.get("file_path")
        knowledge_base_id = message.get("knowledge_base_id")

        logger.info(f"Processing document {document_id}: {file_path}")
        try:
            await self.metadata_db.update_document_status(document_id, "processing")
            parsed_doc = await self.pdf_parser.parse(file_path)
            await self._store_chunks(document_id, parsed_doc)
            await self.metadata_db.update_document_status(
                document_id, "completed", page_count=parsed_doc.total_pages
            )
            logger.info(f"Document {document_id} processed successfully")
        except Exception as e:
            logger.error(f"Failed to process document {document_id}: {e}")
            await self.metadata_db.update_document_status(document_id, "failed", error_message=str(e))

    async def _store_chunks(self, document_id: int, parsed_doc):
        for page in parsed_doc.pages:
            text_chunks = self.pdf_parser.chunk_text(page.text)
            for idx, chunk_text in enumerate(text_chunks):
                embedding = self.embedder.embed_text(chunk_text)[0]
                vector_id = self.vector_db.insert_text_chunk(
                    document_id=document_id,
                    page_number=page.page_number,
                    chunk_index=idx,
                    content=chunk_text,
                    embedding=embedding,
                )
                from models.chunk import ChunkCreate, ChunkType
                chunk_create = ChunkCreate(
                    document_id=document_id,
                    chunk_type=ChunkType.TEXT,
                    content=chunk_text,
                    page_number=page.page_number,
                    chunk_index=idx,
                )
                chunk = await self.metadata_db.create_chunk(chunk_create)
                await self.metadata_db.update_chunk_vector_id(chunk.id, vector_id)
            for idx, image_path in enumerate(page.images):
                try:
                    embedding = self.embedder.embed_images([image_path])[0]
                    vector_id = self.vector_db.insert_image_chunk(
                        document_id=document_id,
                        page_number=page.page_number,
                        chunk_index=idx,
                        image_path=image_path,
                        embedding=embedding,
                    )
                    from models.chunk import ChunkCreate, ChunkType
                    chunk_create = ChunkCreate(
                        document_id=document_id,
                        chunk_type=ChunkType.IMAGE,
                        content=image_path,
                        page_number=page.page_number,
                        chunk_index=idx,
                    )
                    chunk = await self.metadata_db.create_chunk(chunk_create)
                    await self.metadata_db.update_chunk_vector_id(chunk.id, vector_id)
                except Exception as e:
                    logger.error(f"Failed to process image {image_path}: {e}")


async def main():
    import os
    os.makedirs("./data", exist_ok=True)
    worker = DocumentParserWorker()
    await worker.start()


if __name__ == "__main__":
    asyncio.run(main())