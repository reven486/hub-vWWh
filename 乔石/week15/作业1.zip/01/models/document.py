from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class DocumentStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class Document(BaseModel):
    id: int = Field(..., description="Document ID")
    knowledge_base_id: int = Field(..., description="Knowledge base ID")
    filename: str = Field(..., description="Original filename")
    file_path: str = Field(..., description="Stored file path")
    status: DocumentStatus = Field(default=DocumentStatus.PENDING)
    page_count: Optional[int] = Field(None, description="Total pages")
    error_message: Optional[str] = Field(None, description="Error message if failed")
    created_at: datetime = Field(default_factory=datetime.now)
    updated_at: datetime = Field(default_factory=datetime.now)


class DocumentCreate(BaseModel):
    knowledge_base_id: int
    filename: str
    file_path: str


class DocumentResponse(BaseModel):
    id: int
    task_id: str = Field(..., description="Task ID for tracking")
    status: DocumentStatus
    message: str = "Document uploaded successfully"
