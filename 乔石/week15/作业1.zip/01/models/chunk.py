from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ChunkType(str, Enum):
    TEXT = "text"
    IMAGE = "image"


class Chunk(BaseModel):
    id: int = Field(..., description="Chunk ID")
    document_id: int = Field(..., description="Parent document ID")
    chunk_type: ChunkType = Field(..., description="Type: text or image")
    content: str = Field(..., description="Text content or image path")
    page_number: int = Field(..., description="Page number in original PDF")
    chunk_index: int = Field(..., description="Order within the page")
    vector_id: Optional[str] = Field(None, description="Milvus vector ID")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")
    created_at: datetime = Field(default_factory=datetime.now)


class ChunkCreate(BaseModel):
    document_id: int
    chunk_type: ChunkType
    content: str
    page_number: int
    chunk_index: int
    metadata: Optional[dict] = None


class ChunkRetrieveResult(BaseModel):
    chunk: Chunk
    score: float = Field(..., description="Relevance score")
    document_filename: str
