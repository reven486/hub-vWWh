from dataclasses import dataclass
from typing import List, Optional

from loguru import logger

from models.chunk import ChunkRetrieveResult


@dataclass
class RetrievalResult:
    text_chunks: List[ChunkRetrieveResult]
    image_chunks: List[ChunkRetrieveResult]


class Retriever:
    def __init__(self, vector_db, text_embedder, image_embedder=None):
        self.vector_db = vector_db
        self.text_embedder = text_embedder
        self.image_embedder = image_embedder

    async def retrieve(self, query: str, knowledge_base_id: int, top_k: int = 5) -> RetrievalResult:
        query_embedding = self.text_embedder.embed_query(query)
        text_results = self.vector_db.search_text(query_embedding, top_k=top_k)
        image_results = self.vector_db.search_image(query_embedding, top_k=top_k) if self.image_embedder else []
        text_chunks = [
            ChunkRetrieveResult(
                chunk=self._dict_to_chunk(r),
                score=r.get("distance", 0.0),
                document_filename=r.get("filename", ""),
            )
            for r in text_results
        ]
        image_chunks = [
            ChunkRetrieveResult(
                chunk=self._dict_to_chunk(r),
                score=r.get("distance", 0.0),
                document_filename=r.get("filename", ""),
            )
            for r in image_results
        ]
        logger.info(f"Retrieved {len(text_chunks)} text chunks and {len(image_chunks)} image chunks")
        return RetrievalResult(text_chunks=text_chunks, image_chunks=image_chunks)

    def _dict_to_chunk(self, r: dict) -> "Chunk":
        from models.chunk import Chunk, ChunkType
        return Chunk(
            id=r.get("id", 0),
            document_id=r.get("document_id", 0),
            chunk_type=ChunkType(r.get("chunk_type", "text")),
            content=r.get("content", ""),
            page_number=r.get("page_number", 0),
            chunk_index=r.get("chunk_index", 0),
            vector_id=r.get("vector_id"),
        )

    async def retrieve_text_only(self, query: str, top_k: int = 5) -> List[ChunkRetrieveResult]:
        query_embedding = self.text_embedder.embed_query(query)
        results = self.vector_db.search_text(query_embedding, top_k=top_k)
        return [
            ChunkRetrieveResult(
                chunk=self._dict_to_chunk(r),
                score=r.get("distance", 0.0),
                document_filename=r.get("filename", ""),
            )
            for r in results
        ]

    async def retrieve_images_only(self, query: str, top_k: int = 5) -> List[ChunkRetrieveResult]:
        if not self.image_embedder:
            return []
        query_embedding = self.text_embedder.embed_query(query)
        results = self.vector_db.search_image(query_embedding, top_k=top_k)
        return [
            ChunkRetrieveResult(
                chunk=self._dict_to_chunk(r),
                score=r.get("distance", 0.0),
                document_filename=r.get("filename", ""),
            )
            for r in results
        ]