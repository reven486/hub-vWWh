from typing import List, Union

import torch
from loguru import logger
from sentence_transformers import SentenceTransformer

try:
    import clip
    import torchvision.transforms as transforms
    CLIP_AVAILABLE = True
except ImportError:
    CLIP_AVAILABLE = False
    logger.warning("CLIP not available")


class Embedder:
    def __init__(
        self,
        text_model: str = "BAAI/bge-large-zh",
        clip_model: str = "openai/clip-vit-base-patch32",
        device: str = "cuda" if torch.cuda.is_available() else "cpu",
    ):
        self.text_embedder = SentenceTransformer(text_model, device=device)
        self.text_dim = self.text_embedder.get_sentence_embedding_dimension()
        if CLIP_AVAILABLE:
            self.clip_model, self.clip_preprocess = clip.load(clip_model, device=device)
            self.clip_device = device
        else:
            self.clip_model = None
            logger.info("Using text-only embedding mode (CLIP not available)")

    def embed_text(self, texts: Union[str, List[str]]) -> List[List[float]]:
        if isinstance(texts, str):
            texts = [texts]
        embeddings = self.text_embedder.encode(texts, convert_to_numpy=True)
        return embeddings.tolist()

    def embed_images(self, image_paths: List[str]) -> List[List[float]]:
        if not CLIP_AVAILABLE or self.clip_model is None:
            logger.warning("CLIP not available, returning zero embeddings")
            return [[0.0] * 512 for _ in image_paths]
        import clip
        images = [self.clip_preprocess(Image.open(path)).unsqueeze(0) for path in image_paths]
        images = torch.cat(images).to(self.clip_device)
        with torch.no_grad():
            features = self.clip_model.encode_image(images)
            features = features / features.norm(dim=-1, keepdim=True)
        return features.cpu().numpy().tolist()

    def embed_query(self, query: str) -> List[float]:
        return self.embed_text([query])[0]


class TextEmbedder:
    def __init__(self, model_name: str = "BAAI/bge-large-zh", device: str = "cuda"):
        self.model = SentenceTransformer(model_name, device=device)
        self.dim = self.model.get_sentence_embedding_dimension()

    def encode(self, texts: List[str]) -> List[List[float]]:
        return self.model.encode(texts, convert_to_numpy=True).tolist()


class ImageEmbedder:
    def __init__(self, model_name: str = "openai/clip-vit-base-patch32", device: str = "cuda"):
        if not CLIP_AVAILABLE:
            raise RuntimeError("CLIP not available")
        self.device = device
        self.model, self.preprocess = clip.load(model_name, device=device)
        self.dim = 512

    def encode(self, image_paths: List[str]) -> List[List[float]]:
        import torch
        from PIL import Image
        images = [self.preprocess(Image.open(path)).unsqueeze(0) for path in image_paths]
        images = torch.cat(images).to(self.device)
        with torch.no_grad():
            features = self.model.encode_image(images)
            features = features / features.norm(dim=-1, keepdim=True)
        return features.cpu().numpy().tolist()