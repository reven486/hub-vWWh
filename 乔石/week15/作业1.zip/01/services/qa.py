from typing import List, Optional

from loguru import logger

from models.chunk import ChunkRetrieveResult


class QAService:
    def __init__(self, model_name: str = "Qwen/Qwen2-VL-7B-Instruct"):
        self.model_name = model_name
        self.model = None
        self.processor = None

    async def init_model(self):
        try:
            from qwen_vl import Qwen2VLForConditionalGeneration, AutoProcessor
            from transformers import AutoTokenizer, AutoModelForCausalLM
            self.model = Qwen2VLForConditionalGeneration.from_pretrained(self.model_name)
            self.processor = AutoProcessor.from_pretrained(self.model_name)
            logger.info(f"Qwen-VL model loaded: {self.model_name}")
        except ImportError:
            logger.warning("Qwen-VL not available, using mock mode")

    async def generate(
        self,
        query: str,
        text_chunks: List[ChunkRetrieveResult],
        image_chunks: List[ChunkRetrieveResult],
        **kwargs,
    ) -> str:
        context = self._build_context(text_chunks, image_chunks)
        prompt = self._build_prompt(query, context)
        if self.model is None or self.processor is None:
            return self._mock_generate(prompt, context)
        return await self._generate_with_model(prompt, context)

    def _build_context(
        self, text_chunks: List[ChunkRetrieveResult], image_chunks: List[ChunkRetrieveResult]
    ) -> str:
        parts = []
        if text_chunks:
            parts.append("## Reference Text:\n")
            for i, result in enumerate(text_chunks):
                chunk = result.chunk
                parts.append(f"[Page {chunk.page_number}] {chunk.content[:200]}...")
        if image_chunks:
            parts.append("\n## Reference Images:\n")
            for i, result in enumerate(image_chunks):
                chunk = result.chunk
                parts.append(f"[Page {chunk.page_number}] Image: {chunk.content}")
        return "\n".join(parts)

    def _build_prompt(self, query: str, context: str) -> str:
        return f"""Based on the following information, answer the question. Cite your sources using [Page X] notation.

{context}

## Question:
{query}

## Answer:"""

    async def _generate_with_model(self, prompt: str, context: str) -> str:
        try:
            from qwen_vl import Qwen2VLForConditionalGeneration, AutoProcessor
            from qwen_vl.utils import process_vision_info
            import torch
            messages = [
                {"role": "user", "content": [{"type": "text", "text": prompt}]}
            ]
            text = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            image_inputs, video_inputs = process_vision_info(messages)
            inputs = self.processor(text=[text], images=image_inputs, videos=video_inputs, return_tensors="pt").to("cuda")
            with torch.no_grad():
                outputs = self.model.generate(**inputs, max_new_tokens=512)
            response = self.processor.batch_decode(outputs, skip_special_tokens=True)[0]
            return response
        except Exception as e:
            logger.error(f"Model generation failed: {e}, using mock")
            return self._mock_generate(prompt, context)

    def _mock_generate(self, prompt: str, context: str) -> str:
        return f"Based on the provided context, the answer references the relevant information. [This is a mock response when Qwen-VL is not available]"

    async def generate_stream(self, query: str, text_chunks: List[ChunkRetrieveResult], image_chunks: List[ChunkRetrieveResult]):
        response = await self.generate(query, text_chunks, image_chunks)
        for char in response:
            yield char