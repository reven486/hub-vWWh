import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

from loguru import logger

try:
    from mineru import MagicPDF
    MINERU_AVAILABLE = True
except ImportError:
    MINERU_AVAILABLE = False
    logger.warning("mineru not available, will use fallback")


@dataclass
class ParsedPage:
    page_number: int
    text: str
    images: List[str]


@dataclass
class ParsedDocument:
    document_path: str
    total_pages: int
    pages: List[ParsedPage]


class PDFParser:
    def __init__(self, use_mineru: bool = True):
        self.use_mineru = use_mineru and MINERU_AVAILABLE
        if self.use_mineru:
            self.mineru = MagicPDF()

    async def parse(self, file_path: str) -> ParsedDocument:
        if self.use_mineru:
            return await self._parse_with_mineru(file_path)
        return await self._parse_with_pymupdf(file_path)

    async def _parse_with_mineru(self, file_path: str) -> ParsedDocument:
        result = self.mineru.parse(file_path, need_image=True)
        pages = []
        for idx, page_result in enumerate(result):
            images = [img["path"] for img in page_result.get("images", [])]
            pages.append(
                ParsedPage(
                    page_number=idx + 1,
                    text=page_result.get("markdown", ""),
                    images=images,
                )
            )
        return ParsedDocument(document_path=file_path, total_pages=len(pages), pages=pages)

    async def _parse_with_pymupdf(self, file_path: str) -> ParsedDocument:
        import pymupdf
        doc = pymupdf.open(file_path)
        pages = []
        for page_num in range(len(doc)):
            page = doc[page_num]
            text = page.get_text("text")
            image_paths = []
            for img_index, img in enumerate(page.get_images(full=True)):
                xref = img[0]
                pix = pymupdf.Pixmap(doc, xref)
                if pix.n - pix.alpha < 4:
                    img_path = f"{file_path}_page{page_num + 1}_img{img_index}.png"
                    pix.save(img_path)
                    image_paths.append(img_path)
            pages.append(ParsedPage(page_number=page_num + 1, text=text, images=image_paths))
        doc.close()
        logger.info(f"Parsed {len(pages)} pages from {file_path}")
        return ParsedDocument(document_path=file_path, total_pages=len(pages), pages=pages)

    def chunk_text(self, text: str, max_chars: int = 500, overlap: int = 50) -> List[str]:
        if len(text) <= max_chars:
            return [text] if text.strip() else []
        chunks = []
        start = 0
        while start < len(text):
            end = start + max_chars
            if start > 0:
                start -= overlap
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start += max_chars - overlap
        return chunks

    async def extract_metadata(self, file_path: str) -> dict:
        import pymupdf
        doc = pymupdf.open(file_path)
        metadata = {
            "title": doc.metadata.get("title", ""),
            "author": doc.metadata.get("author", ""),
            "page_count": len(doc),
        }
        doc.close()
        return metadata