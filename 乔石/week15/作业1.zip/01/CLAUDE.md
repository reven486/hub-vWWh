# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Multimodal RAG (Retrieval-Augmented Generation) system for answering questions from PDF documents containing both text and images. The system parses PDF documents, stores text chunks and images with embeddings, and uses Qwen-VL for multimodal QA.

## Tech Stack

- **Language**: Python
- **Framework**: FastAPI
- **Models**: Qwen-VL (QA), CLIP (multimodal retrieval), DeepSeek-OCR/mineru (PDF parsing), bge (text embedding)
- **Storage**: SQLite/MySQL (metadata), Milvus (vector database)
- **Message Queue**: Kafka (async document processing)

## Architecture

```
web_page_upload → Kafka → offline_process_worker → Milvus
                                                     ↓
user_chat → CLIP retrieval → Qwen-VL reasoning ← Milvus
```

### Module Design

```
├── api/                    # FastAPI 服务
│   ├── routers/            # API 路由
│   │   ├── upload.py       # 文档上传接口
│   │   └── chat.py         # 问答接口
│   └── main.py             # 应用入口
├── worker/                 # 离线处理服务
│   ├── consumer.py         # Kafka 消费者
│   └── parse_document.py   # 文档解析 Worker
├── services/               # 核心业务逻辑
│   ├── pdf_parser.py       # PDF 解析 (mineru/DeepSeek-OCR)
│   ├── embedder.py         # 向量化 (CLIP/bge)
│   ├── retriever.py        # 检索服务
│   └──qa.py                # 问答服务 (Qwen-VL)
├── storage/                # 存储层
│   ├── file_storage.py     # 文件存储 (本地/OSS)
│   ├── vector_db.py        # Milvus 向量存储
│   └── metadata_db.py      # MySQL 元数据
└── models/                 # 数据模型
    ├── document.py         # 文档实体
    └── chunk.py            # Chunk 实体
```

### Functional Implementation Flow

#### 文档上传流程 (web_page_upload)

```
用户上传 PDF
    ↓
API 存储文件到本地/OSS
    ↓
写入 MySQL: 创建文档记录 (status=pending)
    ↓
发送 Kafka 消息到 parse_topic {document_id, file_path}
    ↓
返回 {task_id} 给用户
```

#### 文档解析流程 (offline_process_worker)

```
从 Kafka parse_topic 消费消息
    ↓
读取 PDF 文件
    ↓
调用 mineru/DeepSeek-OCR 解析
    ↓
提取: Markdown 文本 + 图片列表
    ↓
文本分块 (chunk) → bge embedding → 存入 Milvus
    ↓
图片 → CLIP embedding → 存入 Milvus
    ↓
更新 MySQL: 文档 status=completed
```

#### 问答流程 (web_page_chat)

```
用户提问 + knowledge_base_id
    ↓
Query → bge embedding
    ↓
CLIP 检索: 文本 chunk + 相关图片
    ↓
组装图文上下文 (原始图片 URL 转换)
    ↓
Qwen-VL 多模态推理 → 生成答案
    ↓
返回答案 + 信息来源引用
```

### Core Services

1. **API Server** (FastAPI) - handles upload and chat endpoints
2. **Worker** - consumes Kafka messages, parses PDFs, generates embeddings

### Data Flow

1. `POST /upload/document` - Upload PDF, store file, publish to Kafka
2. **Worker** - Consumes parse tasks, extracts text/images via mineru, chunks & embeds, stores in Milvus
3. `POST /chat` - Embed query, retrieve text+images from Milvus via CLIP, generate answer with Qwen-VL

## Key Interfaces

- `POST /upload/document` - 向指定知识库进行上传文档的操作
    步骤1: 上传文档存储为pdf
    步骤2: 向待文档解析的topic插入一条记录
- `POST /chat` - Multimodal QA, returns answer with source references
    步骤1: 获取用户提问 + 知识库id
    步骤2: 提问embedding， 检索（文本、 图）
    步骤3: 图文排版
    
- worker服务，parse_document
    步骤1: 消费文档解析的topic
    步骤2: 对文档进行解析 (mineru / deepseek-ocr 耗时比较长怎么办？)
    步骤3: 文档切分chunk、chunk embeeding、存储在向量数据库中

## Evaluation

Three metrics (total 1.0):
- Page matching: 0.25
- Filename matching: 0.25
- Answer similarity (Jaccard): 0.5

## Testing

### Test Structure

```
tests/
├── unit/                    # 单元测试
│   ├── test_pdf_parser.py   # PDF 解析模块测试
│   ├── test_embedder.py     # 向量化模块测试
│   └── test_retriever.py    # 检索模块测试
├── integration/             # 集成测试
│   └── test_chat_flow.py    # 完整问答流程测试
└── eval/                    # 评估测试
    └── test_evaluation.py   # 答案质量评估 (三个指标)
```

### Evaluation Metrics

评估输入: `{question, ground_truth_answer, page, filename}` → 输出评分

| 指标 | 满分 | 计算方式 |
|------|------|----------|
| 页面匹配度 | 0.25 | 答案中引用的页码与标准答案匹配 |
| 文件名匹配度 | 0.25 | 答案中引用的文件名与标准答案匹配 |
| 答案相似度 | 0.50 | Jaccard 相似系数 = 交集/并集 |

### Run Tests

```bash
# 运行所有测试
pytest tests/

# 运行单元测试
pytest tests/unit/

# 运行集成测试
pytest tests/integration/

# 运行评估测试
pytest tests/eval/test_evaluation.py -v

# 运行单个测试文件
pytest tests/unit/test_pdf_parser.py -v

# 带覆盖率
pytest tests/ --cov=. --cov-report=html
```

## Code Standards

### Linting & Formatting

```bash
# 代码格式化和检查
ruff check .              # Ruff linting
ruff format .             # Ruff 格式化 (替代 black)

# 类型检查
mypy .                    # MyPy 类型检查

# 完整检查 (CI 使用)
ruff check . && ruff format --check . && mypy .
```

### API Documentation

FastAPI 自动生成 OpenAPI 文档:

- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`
- **OpenAPI JSON**: `http://localhost:8000/openapi.json`

```bash
# 生成离线 API 文档
pip install redoc-cli
redoc-cli bundle -o api_docs.html http://localhost:8000/openapi.json
```

### Pre-commit Hooks

```bash
# 安装 pre-commit
pre-commit install

# 手动运行
pre-commit run --all-files
```

## Commands

```bash
# Install dependencies
pip install -r requirements.txt

# Run API server
uvicorn main:app --reload

# Run worker (separate process)
python -m worker.parse_document
```
