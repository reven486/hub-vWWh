import pytest
from pathlib import Path
import tempfile

from services.pdf_parser import PDFParser, ParsedPage, ParsedDocument


class TestPDFParser:
    @pytest.fixture
    def parser(self):
        return PDFParser(use_mineru=False)

    @pytest.fixture
    def sample_pdf(self):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            yield f.name
        Path(f.name).unlink(missing_ok=True)

    @pytest.mark.asyncio
    async def test_chunk_text_short_text(self, parser):
        text = "This is a short text."
        chunks = parser.chunk_text(text, max_chars=50, overlap=10)
        assert len(chunks) == 1
        assert chunks[0] == text

    @pytest.mark.asyncio
    async def test_chunk_text_long_text(self, parser):
        text = "A" * 200
        chunks = parser.chunk_text(text, max_chars=50, overlap=10)
        assert len(chunks) > 1

    @pytest.mark.asyncio
    async def test_chunk_text_empty(self, parser):
        chunks = parser.chunk_text("", max_chars=50)
        assert len(chunks) == 0

    @pytest.mark.asyncio
    async def test_chunk_text_whitespace(self, parser):
        chunks = parser.chunk_text("   ", max_chars=50)
        assert len(chunks) == 0

    @pytest.mark.asyncio
    async def test_extract_metadata(self, parser, sample_pdf):
        metadata = await parser.extract_metadata(sample_pdf)
        assert "title" in metadata
        assert "author" in metadata
        assert "page_count" in metadata