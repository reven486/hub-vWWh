import pytest
from unittest.mock import MagicMock, AsyncMock

from services.retriever import Retriever, RetrievalResult
from models.chunk import Chunk, ChunkType, ChunkRetrieveResult


class TestRetriever:
    @pytest.fixture
    def mock_vector_db(self):
        db = MagicMock()
        db.search_text = MagicMock(return_value=[])
        db.search_image = MagicMock(return_value=[])
        return db

    @pytest.fixture
    def mock_text_embedder(self):
        embedder = MagicMock()
        embedder.embed_query = MagicMock(return_value=[0.1] * 1024)
        return embedder

    @pytest.fixture
    def mock_image_embedder(self):
        embedder = MagicMock()
        embedder.embed_images = MagicMock(return_value=[[0.1] * 512])
        return embedder

    @pytest.fixture
    def retriever(self, mock_vector_db, mock_text_embedder, mock_image_embedder):
        return Retriever(mock_vector_db, mock_text_embedder, mock_image_embedder)

    @pytest.mark.asyncio
    async def test_retrieve_empty_results(self, retriever, mock_vector_db):
        mock_vector_db.search_text.return_value = []
        mock_vector_db.search_image.return_value = []

        result = await retriever.retrieve("test query", knowledge_base_id=1, top_k=5)

        assert isinstance(result, RetrievalResult)
        assert len(result.text_chunks) == 0
        assert len(result.image_chunks) == 0

    @pytest.mark.asyncio
    async def test_retrieve_text_only(self, retriever, mock_vector_db):
        mock_vector_db.search_text.return_value = [
            {
                "id": 1,
                "document_id": 1,
                "chunk_type": "text",
                "content": "Sample content",
                "page_number": 1,
                "chunk_index": 0,
                "distance": 0.5,
                "filename": "test.pdf",
            }
        ]

        result = await retriever.retrieve_text_only("test query", top_k=5)

        assert len(result) == 1
        assert result[0].chunk.content == "Sample content"

    @pytest.mark.asyncio
    async def test_retrieve_images_only(self, retriever, mock_vector_db, mock_image_embedder):
        mock_vector_db.search_image.return_value = [
            {
                "id": 2,
                "document_id": 1,
                "chunk_type": "image",
                "content": "/path/to/image.png",
                "page_number": 2,
                "chunk_index": 0,
                "distance": 0.3,
            }
        ]

        result = await retriever.retrieve_images_only("test query", top_k=5)

        assert len(result) == 1

    @pytest.mark.asyncio
    async def test_retrieve_no_image_embedder(self, mock_vector_db, mock_text_embedder):
        retriever = Retriever(mock_vector_db, mock_text_embedder, image_embedder=None)
        result = await retriever.retrieve_images_only("test query", top_k=5)
        assert len(result) == 0