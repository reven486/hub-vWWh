import pytest
import numpy as np

from services.embedder import Embedder, TextEmbedder


class TestEmbedder:
    @pytest.fixture
    def embedder(self):
        return Embedder(text_model="BAAI/bge-small-zh")

    def test_embed_text_single(self, embedder):
        result = embedder.embed_text("Hello world")
        assert len(result) == 1
        assert len(result[0]) > 0

    def test_embed_text_multiple(self, embedder):
        result = embedder.embed_text(["Hello", "World"])
        assert len(result) == 2
        assert len(result[0]) > 0

    def test_embed_text_list_input(self, embedder):
        texts = ["First text", "Second text"]
        result = embedder.embed_text(texts)
        assert len(result) == 2

    def test_embed_query(self, embedder):
        result = embedder.embed_query("What is this?")
        assert len(result) > 0
        assert isinstance(result[0], float)

    def test_text_consistency(self, embedder):
        result1 = embedder.embed_text("Test sentence")
        result2 = embedder.embed_text("Test sentence")
        np.testing.assert_allclose(result1, result2, rtol=1e-5)


class TestTextEmbedder:
    @pytest.fixture
    def text_embedder(self):
        return TextEmbedder(model_name="BAAI/bge-small-zh")

    def test_encode(self, text_embedder):
        texts = ["Hello", "World"]
        result = text_embedder.encode(texts)
        assert len(result) == 2
        assert all(len(r) == text_embedder.dim for r in result)