import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from models.chunk import ChunkRetrieveResult, Chunk, ChunkType
from services.qa import QAService


class TestQAService:
    @pytest.fixture
    def qa_service(self):
        service = QAService(model_name="Qwen/Qwen2-VL-7B-Instruct")
        return service

    @pytest.fixture
    def sample_text_chunks(self):
        chunk = Chunk(
            id=1,
            document_id=1,
            chunk_type=ChunkType.TEXT,
            content="Sample text content from the document",
            page_number=1,
            chunk_index=0,
            vector_id="vec_1",
        )
        return [ChunkRetrieveResult(chunk=chunk, score=0.9, document_filename="test.pdf")]

    @pytest.fixture
    def sample_image_chunks(self):
        chunk = Chunk(
            id=2,
            document_id=1,
            chunk_type=ChunkType.IMAGE,
            content="/path/to/image.png",
            page_number=2,
            chunk_index=0,
            vector_id="vec_2",
        )
        return [ChunkRetrieveResult(chunk=chunk, score=0.8, document_filename="test.pdf")]

    @pytest.mark.asyncio
    async def test_generate_mock_response(self, qa_service, sample_text_chunks):
        result = await qa_service.generate(
            query="What is this about?",
            text_chunks=sample_text_chunks,
            image_chunks=[],
        )
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.asyncio
    async def test_generate_with_context(self, qa_service, sample_text_chunks, sample_image_chunks):
        result = await qa_service.generate(
            query="What does the document say?",
            text_chunks=sample_text_chunks,
            image_chunks=sample_image_chunks,
        )
        assert isinstance(result, str)

    @pytest.mark.asyncio
    async def test_build_context_text_only(self, qa_service, sample_text_chunks):
        context = qa_service._build_context(sample_text_chunks, [])
        assert "Reference Text" in context
        assert "Page 1" in context
        assert "Sample text content" in context

    @pytest.mark.asyncio
    async def test_build_context_with_images(self, qa_service, sample_text_chunks, sample_image_chunks):
        context = qa_service._build_context(sample_text_chunks, sample_image_chunks)
        assert "Reference Text" in context
        assert "Reference Images" in context
        assert "Page 2" in context

    @pytest.mark.asyncio
    async def test_generate_stream(self, qa_service, sample_text_chunks):
        chunks = []
        async for char in qa_service.generate_stream("test", sample_text_chunks, []):
            chunks.append(char)
        result = "".join(chunks)
        assert isinstance(result, str)
        assert len(result) > 0