import pytest
from models.chunk import Chunk, ChunkType
from models.document import Document, DocumentStatus


def jaccard_similarity(str1: str, str2: str) -> float:
    set1 = set(str1.lower().split())
    set2 = set(str2.lower().split())
    intersection = set1 & set2
    union = set1 | set2
    return len(intersection) / len(union) if union else 0.0


def extract_page_reference(text: str) -> int | None:
    import re
    match = re.search(r"\[page\s*(\d+)\]", text, re.IGNORECASE)
    return int(match.group(1)) if match else None


def extract_filename_reference(text: str) -> str | None:
    import re
    match = re.search(r"(?:from|file|doc)[:\s]+([^\s]+\.pdf)", text, re.IGNORECASE)
    return match.group(1) if match else None


class TestEvaluationMetrics:
    def test_page_matching_correct(self):
        answer = "According to the document [page 3], the result shows..."
        ground_truth_page = 3
        score = 1.0 if extract_page_reference(answer) == ground_truth_page else 0.0
        assert score == 1.0

    def test_page_matching_incorrect(self):
        answer = "Based on [page 1], the answer is..."
        ground_truth_page = 5
        score = 1.0 if extract_page_reference(answer) == ground_truth_page else 0.0
        assert score == 0.0

    def test_page_matching_no_reference(self):
        answer = "The answer is yes."
        score = 1.0 if extract_page_reference(answer) == 3 else 0.0
        assert score == 0.0

    def test_filename_matching_correct(self):
        answer = "From report.pdf, we can see..."
        ground_truth_filename = "report.pdf"
        extracted = extract_filename_reference(answer)
        score = 1.0 if extracted and extracted.lower() == ground_truth_filename.lower() else 0.0
        assert score == 1.0

    def test_filename_matching_incorrect(self):
        answer = "From other.pdf, we can see..."
        ground_truth_filename = "report.pdf"
        extracted = extract_filename_reference(answer)
        score = 1.0 if extracted and extracted.lower() == ground_truth_filename.lower() else 0.0
        assert score == 0.0

    def test_filename_matching_no_reference(self):
        answer = "The answer is correct."
        extracted = extract_filename_reference(answer)
        score = 1.0 if extracted and extracted.lower() == "report.pdf" else 0.0
        assert score == 0.0

    def test_jaccard_similarity_identical(self):
        text1 = "the quick brown fox jumps over the lazy dog"
        text2 = "the quick brown fox jumps over the lazy dog"
        similarity = jaccard_similarity(text1, text2)
        assert similarity == 1.0

    def test_jaccard_similarity_partial(self):
        text1 = "the quick brown fox"
        text2 = "the quick brown fox jumps over"
        similarity = jaccard_similarity(text1, text2)
        assert 0.0 < similarity < 1.0

    def test_jaccard_similarity_no_overlap(self):
        text1 = "hello world"
        text2 = "foo bar baz"
        similarity = jaccard_similarity(text1, text2)
        assert similarity == 0.0

    def test_jaccard_similarity_case_insensitive(self):
        text1 = "HELLO WORLD"
        text2 = "hello world"
        similarity = jaccard_similarity(text1, text2)
        assert similarity == 1.0


class TestEvaluationIntegration:
    @pytest.fixture
    def sample_evaluation_input(self):
        return {
            "question": "What is the main finding in Q3?",
            "ground_truth_answer": "The sales dropped significantly in Q3 according to the report.pdf [page 5]",
            "answer": "Based on report.pdf [page 5], the main finding is that sales declined substantially in Q3",
            "page": 5,
            "filename": "report.pdf",
        }

    def test_evaluate_full(self, sample_evaluation_input):
        answer = sample_evaluation_input["answer"]
        ground_truth = sample_evaluation_input["ground_truth_answer"]

        page_score = 0.25 if extract_page_reference(answer) == sample_evaluation_input["page"] else 0.0
        filename_score = 0.25 if extract_filename_reference(answer) and extract_filename_reference(answer).lower() == sample_evaluation_input["filename"].lower() else 0.0
        jaccard = jaccard_similarity(answer, ground_truth)
        content_score = 0.5 * jaccard

        total = page_score + filename_score + content_score
        assert 0.0 <= total <= 1.0
        assert page_score == 0.25
        assert filename_score == 0.25
        assert content_score > 0

    def test_evaluate_partial_match(self):
        answer = "The sales dropped in Q3."
        ground_truth = "The sales dropped significantly in Q3 according to the report.pdf [page 5]"
        page_score = 0.25 if extract_page_reference(answer) == 5 else 0.0
        filename_score = 0.25 if extract_filename_reference(answer) and "report.pdf" in extract_filename_reference(answer).lower() else 0.0
        jaccard = jaccard_similarity(answer, ground_truth)
        content_score = 0.5 * jaccard
        assert page_score == 0.0
        assert filename_score == 0.0
        assert 0.0 <= content_score <= 0.5