#!/usr/bin/env python3
"""
快速测试脚本 - 无需 Kafka 和 Milvus
直接测试 PDF 解析和问答功能
"""

import asyncio
import os
import sys

# 确保项目根目录在路径中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pathlib import Path

# 创建数据目录
DATA_DIR = Path("./data")
DATA_DIR.mkdir(exist_ok=True)
(DATA_DIR / "files").mkdir(exist_ok=True)


async def test_pdf_parser():
    """测试 PDF 解析功能"""
    print("\n" + "="*50)
    print("测试 1: PDF 解析")
    print("="*50)

    from services.pdf_parser import PDFParser

    parser = PDFParser(use_mineru=False)

    # 创建一个简单的测试 PDF
    test_pdf = DATA_DIR / "files" / "test.pdf"
    if not test_pdf.exists():
        import pymupdf
        doc = pymupdf.open()
        page = doc.new_page()
        page.insert_text((100, 100), "Hello World! This is a test PDF.")
        page.insert_text((100, 150), "The main finding is that sales dropped in Q3.")
        page.insert_text((100, 200), "See chart on page 2 for details.")
        doc.save(test_pdf)
        doc.close()
        print(f"创建测试 PDF: {test_pdf}")

    # 解析 PDF
    result = await parser.parse(str(test_pdf))
    print(f"\n解析结果:")
    print(f"  总页数: {result.total_pages}")
    for page in result.pages:
        print(f"  Page {page.page_number}: {len(page.text)} chars, {len(page.images)} images")

    # 测试文本分块
    if result.pages:
        chunks = parser.chunk_text(result.pages[0].text, max_chars=50, overlap=10)
        print(f"\n分块结果: {len(chunks)} chunks")
        for i, chunk in enumerate(chunks[:3]):
            print(f"  Chunk {i}: {chunk[:50]}...")

    return True


async def test_embedder():
    """测试向量化功能"""
    print("\n" + "="*50)
    print("测试 2: 向量化 (Text Embedding)")
    print("="*50)

    from services.embedder import Embedder

    embedder = Embedder(text_model="BAAI/bge-small-zh")

    texts = [
        "什么是机器学习？",
        "深度学习是机器学习的一个分支",
        "人工智能的发展历史"
    ]

    embeddings = embedder.embed_text(texts)
    print(f"\n向量化 {len(texts)} 条文本:")
    print(f"  embedding 维度: {len(embeddings[0])}")

    query_emb = embedder.embed_query("深度学习是什么？")
    print(f"  query embedding 维度: {len(query_emb)}")

    return True


async def test_mock_retrieval():
    """测试模拟检索"""
    print("\n" + "="*50)
    print("测试 3: 模拟检索")
    print("="*50)

    from models.chunk import Chunk, ChunkType, ChunkRetrieveResult

    # 模拟检索结果
    chunks = [
        Chunk(
            id=1, document_id=1, chunk_type=ChunkType.TEXT,
            content="Sales dropped significantly in Q3 2024",
            page_number=5, chunk_index=0, vector_id="v1"
        ),
        Chunk(
            id=2, document_id=1, chunk_type=ChunkType.TEXT,
            content="According to the chart, revenue peaked in Q2",
            page_number=3, chunk_index=0, vector_id="v2"
        ),
    ]

    results = [
        ChunkRetrieveResult(chunk=chunk, score=0.9, document_filename="report.pdf")
        for chunk in chunks
    ]

    print(f"\n检索到 {len(results)} 条相关内容:")
    for r in results:
        print(f"  [Page {r.chunk.page_number}] {r.chunk.content[:50]}... (score: {r.score})")

    return True


async def test_qa_service():
    """测试问答服务"""
    print("\n" + "="*50)
    print("测试 4: 问答服务 (Mock Mode)")
    print("="*50)

    from services.qa import QAService
    from models.chunk import Chunk, ChunkType, ChunkRetrieveResult

    qa = QAService()

    # 模拟检索结果
    text_chunks = [
        ChunkRetrieveResult(
            chunk=Chunk(id=1, document_id=1, chunk_type=ChunkType.TEXT,
                        content="The sales dropped significantly in Q3.", page_number=5, chunk_index=0),
            score=0.9, document_filename="report.pdf"
        )
    ]

    query = "What happened to sales in Q3?"
    answer = await qa.generate(query, text_chunks, [])

    print(f"\n问题: {query}")
    print(f"答案: {answer}")

    return True


async def test_metadata_db():
    """测试元数据库"""
    print("\n" + "="*50)
    print("测试 5: 元数据库 (SQLite)")
    print("="*50)

    from storage.metadata_db import MetadataDB
    from models.document import DocumentCreate, DocumentStatus

    db = MetadataDB()
    await db.init_db()

    # 创建文档记录
    doc_create = DocumentCreate(
        knowledge_base_id=1,
        filename="test.pdf",
        file_path="./data/files/test.pdf"
    )
    doc = await db.create_document(doc_create)
    print(f"\n创建文档: id={doc.id}, status={doc.status}")

    # 查询文档
    retrieved = await db.get_document(doc.id)
    print(f"查询文档: id={retrieved.id}, filename={retrieved.filename}")

    # 更新状态
    await db.update_document_status(doc.id, DocumentStatus.COMPLETED, page_count=10)
    updated = await db.get_document(doc.id)
    print(f"更新后状态: {updated.status}")

    return True


async def test_file_storage():
    """测试文件存储"""
    print("\n" + "="*50)
    print("测试 6: 文件存储")
    print("="*50)

    from storage.file_storage import FileStorage

    storage = FileStorage(base_dir=str(DATA_DIR / "files"))

    # 保存文件
    content = b"Hello, this is test content!"
    file_path = await storage.save(content, knowledge_base_id=1, filename="test.txt")

    print(f"\n文件保存: {file_path}")

    # 验证文件存在
    exists = Path(file_path).exists()
    print(f"文件存在: {exists}")

    return True


async def main():
    """运行所有测试"""
    print("\n" + "#"*60)
    print("# Multimodal RAG 快速测试")
    print("#"*60)

    tests = [
        ("PDF 解析", test_pdf_parser),
        ("向量化", test_embedder),
        ("模拟检索", test_mock_retrieval),
        ("问答服务", test_qa_service),
        ("元数据库", test_metadata_db),
        ("文件存储", test_file_storage),
    ]

    results = []
    for name, test_func in tests:
        try:
            success = await test_func()
            results.append((name, "✓ PASS" if success else "✗ FAIL"))
        except Exception as e:
            print(f"\n错误: {e}")
            import traceback
            traceback.print_exc()
            results.append((name, f"✗ ERROR: {e}"))

    # 打印总结
    print("\n" + "="*50)
    print("测试总结")
    print("="*50)
    for name, result in results:
        print(f"  {name}: {result}")

    passed = sum(1 for _, r in results if "PASS" in r)
    print(f"\n通过: {passed}/{len(results)}")

    print("\n" + "="*50)
    print("下一步")
    print("="*50)
    print("""
1. 启动完整服务需要:
   - Milvus (向量数据库)
   - Kafka (消息队列)

2. 快速启动命令:
   # 启动 API (需要先安装依赖)
   uvicorn api.main:app --reload --port 8000

   # 访问 API 文档
   http://localhost:8000/docs
""")


if __name__ == "__main__":
    asyncio.run(main())