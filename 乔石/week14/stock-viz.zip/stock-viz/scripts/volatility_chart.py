#!/usr/bin/env python3
"""
股票波动率分析与可视化
用法: python3 volatility_chart.py <股票代码> [开始日期] [结束日期]
示例: python3 volatility_chart.py sh600519 20250101 20260514
"""

import sys
import os
import requests
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta

TOKEN = "zgaLG8unUPr"
BASE_URL = "https://api.autostock.cn/v1"

# ─── 中文字体支持 ──────────────────────────────────────────────
plt.rcParams["font.sans-serif"] = [
    "PingFang SC", "Heiti SC", "STHeiti", "Arial Unicode MS",
    "Microsoft YaHei", "SimHei", "DejaVu Sans",
]
plt.rcParams["axes.unicode_minus"] = False


# ─── 数据获取 ──────────────────────────────────────────────────

def fetch_kline(period, code, start_date=None, end_date=None, type_=1):
    """获取K线数据。period: 'week' | 'day'"""
    url = f"{BASE_URL}/stock/kline/{period}"
    params = {"token": TOKEN, "code": code, "type": type_}
    if start_date:
        params["startDate"] = start_date
    if end_date:
        params["endDate"] = end_date
    try:
        resp = requests.get(url, params=params, timeout=10)
        return resp.json()
    except Exception as e:
        print(f"获取{period}K线失败: {e}")
        return None


def fetch_stock_info(code):
    """获取股票基础信息"""
    url = f"{BASE_URL}/stock"
    params = {"token": TOKEN, "code": code}
    try:
        resp = requests.get(url, params=params, timeout=10)
        return resp.json()
    except Exception:
        return None


# ─── 波动率计算 ────────────────────────────────────────────────

def parse_kline(raw):
    """
    解析K线原始数据。
    返回: [(date_str, open, close, high, low, volume), ...]
    """
    if not raw or "data" not in raw or not raw["data"]:
        return []
    result = []
    for item in raw["data"]:
        try:
            date_str = str(item[0])
            o, c, h, l = float(item[1]), float(item[2]), float(item[3]), float(item[4])
            vol = float(item[5]) if len(item) > 5 else 0
            result.append((date_str, o, c, h, l, vol))
        except (IndexError, ValueError):
            continue
    return result


def calc_volatility(klines):
    """计算波动率 = (high - low) / close * 100"""
    result = []
    for date_str, o, c, h, l, v in klines:
        if c > 0:
            vol = (h - l) / c * 100
            result.append((date_str, round(vol, 2)))
    return result


def moving_average(values, window):
    """简单移动平均"""
    if len(values) < window:
        return [np.nan] * len(values)
    result = []
    for i in range(len(values)):
        if i < window - 1:
            result.append(np.nan)
        else:
            result.append(round(np.nanmean(values[i - window + 1 : i + 1]), 2))
    return result


# ─── 买卖信号计算 ──────────────────────────────────────────────

def generate_signals(day_vol, week_vol):
    """
    基于波动率生成买卖信号。
    返回: list of (date, signal_type, reason)
      signal_type: 1=买入, -1=卖出, 0=观望
    """
    signals = []

    if not week_vol or not day_vol:
        return signals

    # 周波动率百分位计算
    week_vols = [v for _, v in week_vol]
    week_p25 = np.percentile(week_vols, 25) if week_vols else 0
    week_p75 = np.percentile(week_vols, 75) if week_vols else 0

    # 建立日期索引
    day_dict = dict(day_vol)
    week_dict = dict(week_vol)

    # 日波动信号
    day_dates = [d for d, _ in day_vol]
    day_values = [v for _, v in day_vol]

    for i in range(len(day_dates)):
        d = day_dates[i]
        dv = day_values[i]
        wv = week_dict.get(d)
        if wv is None:
            continue

        # 日波动率下穿周波动率
        if i > 0 and day_dates[i - 1] in day_dict:
            prev_dv = day_values[i - 1]
            prev_wv = week_dict.get(day_dates[i - 1])
            if prev_wv is not None:
                if prev_dv >= prev_wv and dv < wv and wv < week_p25:
                    signals.append((d, 1, "日波动下穿周波动且周波动低位"))
                if prev_dv <= prev_wv and dv > wv and wv > week_p75:
                    signals.append((d, -1, "日波动上穿周波动且周波动高位"))

    # 周波动率趋势信号
    week_dates = [d for d, _ in week_vol]
    week_values = [v for _, v in week_vol]

    for i in range(2, len(week_dates)):
        v0, v1, v2 = week_values[i - 2], week_values[i - 1], week_values[i]
        if v0 > v1 > v2 and v2 < week_p25:
            signals.append((week_dates[i], 1, "周波动连续3周递减且处于低位"))
        if v0 < v1 < v2 and v2 > week_p75:
            signals.append((week_dates[i], -1, "周波动连续3周递增且处于高位"))

    # 去重：同一天只保留最强烈的信号
    signal_map = {}
    for d, s, r in signals:
        if d not in signal_map or abs(s) > abs(signal_map[d][0]):
            signal_map[d] = (s, r)

    return [(d, s, r) for d, (s, r) in sorted(signal_map.items())]


def generate_recommendation(day_vol, week_vol, day_klines):
    """生成综合买卖建议"""
    if not day_vol or not week_vol:
        return "数据不足", "无法分析", "请检查股票代码或日期范围"

    latest_day_vol = day_vol[-1][1]
    latest_week_vol = week_vol[-1][1]

    day_vol_values = [v for _, v in day_vol]
    week_vol_values = [v for _, v in week_vol]

    day_avg20 = np.mean(day_vol_values[-20:]) if len(day_vol_values) >= 20 else np.mean(day_vol_values)
    week_avg20 = np.percentile(week_vol_values, 50)

    week_p25 = np.percentile(week_vol_values, 25)
    week_p75 = np.percentile(week_vol_values, 75)

    diff = round(latest_day_vol - latest_week_vol, 2)

    # 判断建议
    if latest_week_vol < week_p25:
        signal = "🟢 买入窗口"
        reason = "周波动率处于近20周25%分位以下，波动收敛蓄势，突破在即"
        action = "可考虑逢低建仓或加仓"
    elif latest_week_vol > week_p75:
        signal = "🔴 卖出窗口"
        reason = "周波动率处于近20周75%分位以上，波动放大，风险增加"
        action = "可考虑减仓或止盈"
    elif diff < -1.5:
        signal = "🟢 买入时机"
        reason = "日波动率明显低于周波动率，短期波动收敛"
        action = "可考虑适度建仓"
    elif diff > 1.5:
        signal = "🔴 卖出时机"
        reason = "日波动率明显高于周波动率，短期波动加剧"
        action = "可考虑适度减仓"
    else:
        signal = "🟡 观望"
        reason = "波动率处于中间区域，无明确方向"
        action = "建议等待更明确的信号"

    # 止损参考
    if day_klines:
        recent_lows = [k[4] for k in day_klines[-5:]]
        stop_loss = round(min(recent_lows) * 0.97, 2)
    else:
        stop_loss = "N/A"

    return signal, f"{reason}\n建议操作：{action}", f"止损参考：近5日最低价下方3% → {stop_loss}"


# ─── 可视化 ────────────────────────────────────────────────────

def plot_volatility(code, day_klines, week_klines, day_vol, week_vol, stock_name=""):
    """绘制波动率分析图表"""

    fig, axes = plt.subplots(3, 1, figsize=(16, 14), gridspec_kw={"height_ratios": [3, 3, 2]})
    fig.suptitle(f"{'  ' + stock_name if stock_name else ''} ({code}) 波动率分析",
                 fontsize=16, fontweight="bold", y=0.98)

    # ─── 子图1: 日K线收盘价 + 均线 ────────────────────────────
    ax1 = axes[0]
    if day_klines:
        dates = [datetime.strptime(str(k[0]), "%Y%m%d") for k in day_klines]
        closes = [k[2] for k in day_klines]

        ax1.plot(dates, closes, color="#1a1a2e", linewidth=1.2, label="收盘价")

        ma5 = moving_average(closes, 5)
        ma10 = moving_average(closes, 10)
        ax1.plot(dates, ma5, color="#e94560", linewidth=1, alpha=0.8, label="MA5")
        ax1.plot(dates, ma10, color="#0f3460", linewidth=1, alpha=0.8, label="MA10")

        ax1.set_ylabel("价格", fontsize=11)
        ax1.legend(loc="upper left", fontsize=9)
        ax1.set_title("日K线收盘价走势", fontsize=12, pad=8)
        ax1.grid(True, alpha=0.3)
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
        ax1.xaxis.set_major_locator(mdates.MonthLocator())
        plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha="right", fontsize=8)

    # ─── 子图2: 日/周波动率对比 ────────────────────────────────
    ax2 = axes[1]

    # 日波动率
    if day_vol:
        day_dates = [datetime.strptime(str(d), "%Y%m%d") for d, _ in day_vol]
        day_values = [v for _, v in day_vol]
        ax2.bar(day_dates, day_values, width=0.8, color="#4ecdc4", alpha=0.6, label="日波动率")

        # 日波动率均值线
        day_ma20 = moving_average(day_values, 20)
        ax2.plot(day_dates, day_ma20, color="#2d6a4f", linewidth=1.5,
                 linestyle="--", label="日波动MA20")

    # 周波动率（在同一图上用不同颜色）
    if week_vol:
        week_dates = [datetime.strptime(str(d), "%Y%m%d") for d, _ in week_vol]
        week_values = [v for _, v in week_vol]
        ax2.plot(week_dates, week_values, color="#e63946", linewidth=2.2,
                 marker="o", markersize=4, label="周波动率", zorder=5)

        # 周波动率均值线
        week_ma10 = moving_average(week_values, 10)
        ax2.plot(week_dates, week_ma10, color="#a8dadc", linewidth=1.5,
                 linestyle="--", label="周波动MA10")

        # 百分位线
        if week_values:
            p25 = np.percentile(week_values, 25)
            p75 = np.percentile(week_values, 75)
            ax2.axhline(y=p25, color="#2d6a4f", linestyle=":", alpha=0.7,
                         label=f"周波动25%分位 ({p25:.1f}%)")
            ax2.axhline(y=p75, color="#e63946", linestyle=":", alpha=0.7,
                         label=f"周波动75%分位 ({p75:.1f}%)")

    ax2.set_ylabel("波动率 (%)", fontsize=11)
    ax2.legend(loc="upper left", fontsize=8, ncol=2)
    ax2.set_title("日波动率 vs 周波动率", fontsize=12, pad=8)
    ax2.grid(True, alpha=0.3)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
    ax2.xaxis.set_major_locator(mdates.MonthLocator())
    plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha="right", fontsize=8)

    # ─── 子图3: 波动率差值 + 买卖信号 ─────────────────────────
    ax3 = axes[2]

    signals = generate_signals(day_vol, week_vol)

    # 计算差值
    week_dict = dict(week_vol)
    if day_vol:
        diff_dates = []
        diff_values = []
        for d, dv in day_vol:
            wv = week_dict.get(d)
            if wv is not None:
                diff_dates.append(datetime.strptime(str(d), "%Y%m%d"))
                diff_values.append(round(dv - wv, 2))

        if diff_dates:
            colors = ["#2d6a4f" if v < 0 else "#e63946" for v in diff_values]
            ax3.bar(diff_dates, diff_values, width=0.8, color=colors, alpha=0.6,
                    label="日波动率 - 周波动率")
            ax3.axhline(y=0, color="gray", linewidth=0.8)

    # 标注买卖信号
    for d, s, r in signals:
        dt = datetime.strptime(str(d), "%Y%m%d")
        if s == 1:
            ax3.annotate("B", xy=(dt, 0), fontsize=11, fontweight="bold",
                         color="#2d6a4f", ha="center", va="bottom",
                         xytext=(0, 10), textcoords="offset points",
                         bbox=dict(boxstyle="round,pad=0.3", fc="#d4edda", ec="#2d6a4f", alpha=0.8))
        elif s == -1:
            ax3.annotate("S", xy=(dt, 0), fontsize=11, fontweight="bold",
                         color="#e63946", ha="center", va="top",
                         xytext=(0, -10), textcoords="offset points",
                         bbox=dict(boxstyle="round,pad=0.3", fc="#f8d7da", ec="#e63946", alpha=0.8))

    ax3.set_ylabel("波动率差值 (%)", fontsize=11)
    ax3.set_xlabel("日期", fontsize=11)
    ax3.legend(loc="upper left", fontsize=9)
    ax3.set_title("波动率差值 & 买卖信号 (B=买入 S=卖出)", fontsize=12, pad=8)
    ax3.grid(True, alpha=0.3)
    ax3.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d"))
    ax3.xaxis.set_major_locator(mdates.MonthLocator())
    plt.setp(ax3.xaxis.get_majorticklabels(), rotation=45, ha="right", fontsize=8)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    output_path = f"/tmp/stock_viz_{code}.png"
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"图表已保存: {output_path}")
    return output_path


# ─── 主流程 ────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("用法: python3 volatility_chart.py <股票代码> [开始日期] [结束日期]")
        print("示例: python3 volatility_chart.py sh600519 20250101 20260514")
        sys.exit(1)

    code = sys.argv[1]
    start_date = sys.argv[2] if len(sys.argv) > 2 else None
    end_date = sys.argv[3] if len(sys.argv) > 3 else None

    # 默认取最近一年
    if not start_date:
        start_date = (datetime.now() - timedelta(days=365)).strftime("%Y%m%d")
    if not end_date:
        end_date = datetime.now().strftime("%Y%m%d")

    print(f"正在获取 {code} 的K线数据...")

    # 获取数据
    week_raw = fetch_kline("week", code, start_date, end_date)
    day_raw = fetch_kline("day", code, start_date, end_date)
    info_raw = fetch_stock_info(code)

    # 解析数据
    day_klines = parse_kline(day_raw)
    week_klines = parse_kline(week_raw)

    if not day_klines and not week_klines:
        print(f"无法获取 {code} 的K线数据，请检查股票代码")
        sys.exit(1)

    stock_name = ""
    if info_raw and "data" in info_raw and info_raw["data"]:
        stock_name = info_raw["data"].get("name", "")

    print(f"获取到 日K线 {len(day_klines)} 条, 周K线 {len(week_klines)} 条")

    # 计算波动率
    day_vol = calc_volatility(day_klines)
    week_vol = calc_volatility(week_klines)

    # 绘图
    chart_path = plot_volatility(code, day_klines, week_klines, day_vol, week_vol, stock_name)

    # 生成建议
    signal, reason, stop_loss = generate_recommendation(day_vol, week_vol, day_klines)

    # 输出结果
    latest_day_vol = day_vol[-1][1] if day_vol else 0
    latest_week_vol = week_vol[-1][1] if week_vol else 0
    day_avg = round(np.mean([v for _, v in day_vol[-20:]]), 2) if len(day_vol) >= 20 else "N/A"
    week_avg = round(np.mean([v for _, v in week_vol[-20:]]), 2) if len(week_vol) >= 20 else "N/A"
    diff = round(latest_day_vol - latest_week_vol, 2) if day_vol and week_vol else "N/A"
    current_price = day_klines[-1][2] if day_klines else "N/A"

    print()
    print("━" * 42)
    print(f" 股票：{stock_name} ({code})")
    print(f" 当前价：{current_price}")
    print(f" 分析周期：{start_date} ~ {end_date}")
    print("━" * 42)
    print()
    print(" 📊 波动率概览")
    print(f" ├─ 最新日波动率：{latest_day_vol}%")
    print(f" ├─ 最新周波动率：{latest_week_vol}%")
    print(f" ├─ 日波动20日均值：{day_avg}%")
    print(f" ├─ 周波动20周均值：{week_avg}%")
    print(f" └─ 波动率差值(日-周)：{diff}%")
    print()
    print(" 📈 买卖建议")
    print(f" ├─ 信号：{signal}")
    print(f" ├─ 理由：{reason}")
    print(f" └─ {stop_loss}")
    print()
    print(" ⚠️  风险提示")
    print(" └─ 以上建议仅供参考，不构成投资建议")
    print("━" * 42)


if __name__ == "__main__":
    main()
