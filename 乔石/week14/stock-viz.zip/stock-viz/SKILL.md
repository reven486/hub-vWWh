---
name: 股票波动分析与可视化
description: 基于autostock API获取股票日K/周K数据，计算波动率，将日波动与周波动绘制在同一图中，并基于波动率大小给出买入卖出最佳时机建议。
---

# 股票波动分析与可视化

通过调用 autostock API (`https://api.autostock.cn`) 获取股票的日K线和周K线数据，计算波动率指标，生成可视化图表，并基于波动率分析提供买卖时机建议。

## 功能概览

1. **数据获取** — 调用 autostock API 获取日K线和周K线数据
2. **波动率计算** — 分别计算日波动率和周波动率
3. **可视化图表** — 将日/周波动率绘制在同一张图中
4. **买卖建议** — 基于波动率大小和趋势给出操作建议

## 使用方式

用户输入股票代码后，执行以下步骤：

### 第一步：获取数据

调用 autostock API 获取该股票的日K线和周K线数据：

```python
TOKEN = "zgaLG8unUPr"
import requests

def fetch_week_line(code, start_date=None, end_date=None, type_=1):
    """获取周K线数据"""
    url = "https://api.autostock.cn/v1/stock/kline/week"
    params = {"token": TOKEN, "code": code, "type": type_}
    if start_date:
        params["startDate"] = start_date
    if end_date:
        params["endDate"] = end_date
    resp = requests.get(url, params=params, timeout=10)
    return resp.json()

def fetch_day_line(code, start_date=None, end_date=None, type_=1):
    """获取日K线数据"""
    url = "https://api.autostock.cn/v1/stock/kline/day"
    params = {"token": TOKEN, "code": code, "type": type_}
    if start_date:
        params["startDate"] = start_date
    if end_date:
        params["endDate"] = end_date
    resp = requests.get(url, params=params, timeout=10)
    return resp.json()

def fetch_stock_info(code):
    """获取股票基础信息"""
    url = f"https://api.autostock.cn/v1/stock?token={TOKEN}&code={code}"
    resp = requests.get(url, timeout=10)
    return resp.json()
```

### 第二步：计算波动率

```python
def calc_volatility(kline_data):
    """
    计算波动率 = (最高价 - 最低价) / 收盘价 * 100
    kline_data 结构: {"data": [[date, open, close, high, low, volume, ...], ...]}
    返回: [(date, volatility%), ...]
    """
    result = []
    if not kline_data or "data" not in kline_data:
        return result
    for item in kline_data["data"]:
        date = item[0]
        high = float(item[3])
        low = float(item[4])
        close = float(item[2])
        if close > 0:
            vol = (high - low) / close * 100
            result.append((date, round(vol, 2)))
    return result
```

### 第三步：生成可视化图表

运行 `scripts/volatility_chart.py` 生成图表。图表包含三个子图：

- **上方**：日K线走势图（收盘价 + MA5/MA10均线）
- **中间**：日波动率与周波动率叠加对比图
- **下方**：波动率差值（日波动 - 周波动）与买卖信号

```bash
python3 scripts/volatility_chart.py <股票代码> [开始日期] [结束日期]
# 示例：
python3 scripts/volatility_chart.py sh600519 20250101 20260514
python3 scripts/volatility_chart.py sz000858
```

图表会保存到 `/tmp/stock_viz_<股票代码>.png`。

### 第四步：生成买卖建议

基于波动率分析，按以下规则给出建议：

#### 波动率分析规则

| 条件 | 信号 | 说明 |
|------|------|------|
| 周波动率处于近20周低位（< 25%分位） | 🟢 买入窗口 | 波动收敛，蓄势待发，价格即将选择方向，历史上低位波动后常有突破 |
| 日波动率下穿周波动率 | 🟢 买入时机 | 日内波动收窄，市场分歧减少，方向即将明确 |
| 周波动率连续3周递减且处于低位 | 🟢 强买入 | 持续缩量整理，突破在即 |
| 周波动率处于近20周高位（> 75%分位） | 🔴 卖出窗口 | 波动放大，风险增加，可能见顶或即将回调 |
| 日波动率上穿周波动率 | 🔴 卖出时机 | 日内波动加剧，市场分歧增大，短期可能回调 |
| 周波动率连续3周递增且处于高位 | 🔴 强卖出 | 波动持续放大，趋势可能反转 |
| 日/周波动率交织震荡 | 🟡 观望 | 无明确方向，建议等待 |

#### 输出格式

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 股票：贵州茅台 (sh600519)
 当前价：1,856.00
 分析周期：2025-01-01 ~ 2026-05-14
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

 📊 波动率概览
 ├─ 最新日波动率：2.35%
 ├─ 最新周波动率：4.12%
 ├─ 日波动20日均值：2.68%
 ├─ 周波动20周均值：4.55%
 └─ 波动率差值(日-周)：-1.77%

 📈 买卖建议
 ├─ 信号：🟢 买入窗口
 ├─ 理由：周波动率处于近20周25%分位以下，波动收敛蓄势
 ├─ 建议操作：可考虑逢低建仓或加仓
 └─ 止损参考：近5日最低价下方 3%

 ⚠️  风险提示
 └─ 以上建议仅供参考，不构成投资建议
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## 依赖

```bash
pip install requests matplotlib numpy
```

## 注意事项

- API Token 已内置于脚本中，如需更换请修改 `TOKEN` 变量
- 日K线和周K线默认使用前复权（type=1）
- 不传日期参数时，默认获取最近一年的数据
- 图表保存路径为 `/tmp/stock_viz_<code>.png`
- 波动率建议为量化参考，不构成投资建议
