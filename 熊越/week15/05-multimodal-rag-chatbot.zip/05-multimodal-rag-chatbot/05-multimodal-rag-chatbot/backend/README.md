# FastAPI Backend - 多模态 RAG 聊天机器人

基于 FastAPI 构建的后端 API，实现多模态 RAG（检索增强生成）聊天机器人功能。

## 功能特性

- **文件管理**: 支持 PDF、DOCX、TXT、MD 文件的上传、查询和删除
- **RAG 问答**: 基于向量检索的智能问答，支持多轮对话
- **会话管理**: 支持创建、查询、删除聊天会话
- **多模态支持**: 支持文本、图片等多种内容类型的理解和生成

## 技术栈

- **Web 框架**: FastAPI
- **数据库**: SQLite (SQLAlchemy ORM)
- **向量数据库**: Milvus
- **消息队列**: Kafka
- **嵌入模型**: BGE-small-zh-v1.5
- **多模态模型**: jina-clip-v2
- **大语言模型**: DeepSeek-V4-Pro (via DashScope)

## 项目结构

```
backend/
├── app/
│   ├── api/
│   │   └── v1/
│   │       ├── endpoints/       # API 路由端点
│   │       │   ├── files.py     # 文件管理 API
│   │       │   ├── chat.py      # 聊天 API
│   │       │   └── system.py    # 系统 API
│   │       ├── __init__.py
│   │       └── api.py           # 路由聚合
│   ├── core/
│   │   ├── __init__.py
│   │   └── config.py            # 应用配置
│   ├── models/
│   │   ├── __init__.py
│   │   ├── database.py          # 数据库配置
│   │   └── models.py            # 数据模型
│   ├── schemas/
│   │   ├── __init__.py
│   │   └── schemas.py           # Pydantic 模型
│   ├── services/
│   │   ├── __init__.py
│   │   ├── file_service.py      # 文件服务
│   │   ├── chat_service.py      # 聊天服务
│   │   └── milvus_service.py    # Milvus 服务
│   ├── __init__.py
│   └── main.py                  # 应用主入口
├── .env                         # 环境变量（需创建）
├── .env.example                 # 环境变量示例
├── requirements.txt             # 依赖包
├── run.py                       # 启动脚本
└── README.md                    # 本文件
```

## 快速开始

### 1. 安装依赖

```bash
cd backend
pip install -r requirements.txt
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，填入实际的配置值
```

### 3. 启动服务

```bash
# 方式1: 使用启动脚本
python run.py

# 方式2: 使用 uvicorn 命令
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### 4. 访问 API 文档

启动后访问: http://localhost:8000/docs

## API 接口列表

### 文件管理

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/v1/files/upload` | 上传文件 |
| GET | `/api/v1/files/list` | 获取文件列表 |
| GET | `/api/v1/files/{file_id}` | 获取文件详情 |
| DELETE | `/api/v1/files/{file_id}` | 删除文件 |

### RAG 问答

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/v1/chat/send` | 发送消息 |
| GET | `/api/v1/chat/sessions` | 获取会话列表 |
| POST | `/api/v1/chat/sessions` | 创建新会话 |
| GET | `/api/v1/chat/sessions/{session_id}` | 获取会话详情 |
| GET | `/api/v1/chat/sessions/{session_id}/messages` | 获取会话消息 |
| DELETE | `/api/v1/chat/sessions/{session_id}` | 删除会话 |

### 系统

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/v1/system/health` | 健康检查 |
| GET | `/api/v1/system/info` | 系统信息 |
| GET | `/api/v1/system/milvus/stats` | Milvus 统计 |

## 环境变量配置

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `DATABASE_URL` | 数据库连接 URL | `sqlite:///./db.db` |
| `MILVUS_URI` | Milvus 服务地址 | 必填 |
| `MILVUS_TOKEN` | Milvus 访问令牌 | 必填 |
| `KAFKA_BOOTSTRAP_SERVERS` | Kafka 地址 | `localhost:9092` |
| `DASHSCOPE_API_KEY` | DashScope API 密钥 | 必填 |
| `BGE_MODEL_PATH` | BGE 模型路径 | `/root/autodl-tmp/models/BAAI/bge-small-zh-v1.5` |
| `CLIP_MODEL_PATH` | CLIP 模型路径 | `/root/autodl-tmp/models/jinaai/jina-clip-v2` |
| `UPLOAD_DIR` | 文件上传目录 | `./uploads` |
| `MAX_FILE_SIZE` | 最大文件大小 | `104857600` (100MB) |

## 依赖服务

- **Kafka**: 用于文件处理任务的异步队列
- **Milvus**: 向量数据库存储文档向量
- **MinerU**: 文档解析服务 (http://127.0.0.1:30000)
- **DashScope**: 大语言模型 API 服务

## 注意事项

1. 确保 Kafka、Milvus 等依赖服务已启动
2. 模型文件路径需要正确配置
3. 文件上传后会自动发送到 Kafka 进行异步处理
4. 删除文件时会同时删除数据库记录、本地文件和向量数据
