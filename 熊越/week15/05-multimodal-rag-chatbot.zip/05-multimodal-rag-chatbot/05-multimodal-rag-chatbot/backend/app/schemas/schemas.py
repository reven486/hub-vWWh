"""
Pydantic 模型定义（Schema）
用于请求验证和响应序列化
"""
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, Field
from datetime import datetime


# ==================== 基础响应模型 ====================

class ResponseBase(BaseModel):
    """基础响应模型"""
    code: int = Field(default=200, description="状态码")
    message: str = Field(default="success", description="消息")


class DataResponse(ResponseBase):
    """带数据的响应模型"""
    data: Optional[Any] = Field(default=None, description="数据")


class ListResponse(ResponseBase):
    """列表响应模型"""
    data: List[Any] = Field(default=[], description="数据列表")
    total: int = Field(default=0, description="总数")


# ==================== 文件相关模型 ====================

class FileBase(BaseModel):
    """文件基础模型"""
    filename: str = Field(..., description="文件名")
    filestate: str = Field(default="已上传", description="处理状态")


class FileCreate(FileBase):
    """文件创建模型"""
    filepath: str = Field(..., description="文件路径")
    file_size: Optional[int] = Field(default=None, description="文件大小")
    file_type: Optional[str] = Field(default=None, description="文件类型")


class FileResponse(FileBase):
    """文件响应模型"""
    id: int = Field(..., description="文件ID")
    filepath: str = Field(..., description="文件路径")
    file_size: Optional[int] = Field(default=None, description="文件大小")
    file_type: Optional[str] = Field(default=None, description="文件类型")
    created_at: datetime = Field(..., description="创建时间")
    updated_at: datetime = Field(..., description="更新时间")
    
    class Config:
        from_attributes = True


class FileUploadResponse(DataResponse):
    """文件上传响应"""
    data: Optional[FileResponse] = None


class FileListResponse(ListResponse):
    """文件列表响应"""
    data: List[FileResponse] = []


# ==================== 聊天相关模型 ====================

class ChatMessageBase(BaseModel):
    """聊天消息基础模型"""
    role: str = Field(..., description="角色: user/assistant/system")
    content: str = Field(..., description="消息内容")


class ChatMessageCreate(ChatMessageBase):
    """创建聊天消息"""
    session_id: Optional[str] = Field(default=None, description="会话ID")
    retrieval_results: Optional[str] = Field(default=None, description="检索结果JSON")


class ChatMessageResponse(ChatMessageBase):
    """聊天消息响应"""
    id: int = Field(..., description="消息ID")
    session_id: str = Field(..., description="会话ID")
    created_at: datetime = Field(..., description="创建时间")
    retrieval_results: Optional[str] = Field(default=None, description="检索结果JSON")
    
    class Config:
        from_attributes = True


class ChatSessionBase(BaseModel):
    """聊天会话基础模型"""
    title: Optional[str] = Field(default=None, description="会话标题")


class ChatSessionCreate(ChatSessionBase):
    """创建聊天会话"""
    session_id: str = Field(..., description="会话ID")


class ChatSessionResponse(ChatSessionBase):
    """聊天会话响应"""
    id: int = Field(..., description="会话ID")
    session_id: str = Field(..., description="会话唯一标识")
    created_at: datetime = Field(..., description="创建时间")
    updated_at: datetime = Field(..., description="更新时间")
    messages: List[ChatMessageResponse] = Field(default=[], description="消息列表")
    
    class Config:
        from_attributes = True


class ChatRequest(BaseModel):
    """聊天请求"""
    message: str = Field(..., description="用户消息")
    session_id: Optional[str] = Field(default=None, description="会话ID，为空则创建新会话")
    top_k: int = Field(default=5, description="检索结果数量")


class RetrievalResult(BaseModel):
    """检索结果"""
    text: str = Field(..., description="文本内容")
    db_id: int = Field(..., description="文件ID")
    file_name: str = Field(..., description="文件名")
    file_path: str = Field(..., description="文件路径")
    distance: float = Field(..., description="相似度距离")


class ChatResponseData(BaseModel):
    """聊天响应数据"""
    session_id: str = Field(..., description="会话ID")
    message: str = Field(..., description="AI回复内容")
    retrieval_results: List[RetrievalResult] = Field(default=[], description="检索结果")


class ChatResponse(DataResponse):
    """聊天响应"""
    data: Optional[ChatResponseData] = None


class ChatSessionListResponse(ListResponse):
    """会话列表响应"""
    data: List[ChatSessionResponse] = []


# ==================== 系统状态模型 ====================

class SystemStatus(BaseModel):
    """系统状态"""
    status: str = Field(..., description="系统状态")
    version: str = Field(..., description="API版本")
    milvus_connected: bool = Field(..., description="Milvus连接状态")
    kafka_connected: bool = Field(..., description="Kafka连接状态")


class StatusResponse(DataResponse):
    """状态响应"""
    data: Optional[SystemStatus] = None
