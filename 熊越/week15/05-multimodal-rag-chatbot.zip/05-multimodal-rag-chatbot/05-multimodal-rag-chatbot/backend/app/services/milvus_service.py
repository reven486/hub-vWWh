"""
Milvus 向量数据库服务
处理向量检索和存储相关操作
"""
from typing import List, Dict, Any, Optional
from pymilvus import MilvusClient
import numpy as np

from app.core.config import settings


class MilvusService:
    """Milvus 服务类"""
    
    def __init__(self):
        self.client: Optional[MilvusClient] = None
        self.collection_name = settings.MILVUS_COLLECTION
        self._connect()
    
    def _connect(self):
        """连接到 Milvus"""
        try:
            self.client = MilvusClient(
                uri=settings.MILVUS_URI,
                token=settings.MILVUS_TOKEN
            )
            print("Milvus 连接成功")
        except Exception as e:
            print(f"Milvus 连接失败: {e}")
            self.client = None
    
    def is_connected(self) -> bool:
        """检查是否已连接"""
        return self.client is not None
    
    def search_by_text(
        self, 
        query_vector: List[float], 
        top_k: int = 5,
        output_fields: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        使用文本向量进行检索
        
        Args:
            query_vector: 查询向量
            top_k: 返回结果数量
            output_fields: 返回的字段列表
            
        Returns:
            检索结果列表
        """
        if not self.is_connected():
            raise ConnectionError("Milvus 未连接")
        
        if output_fields is None:
            output_fields = ["text", "db_id", "file_name", "file_path"]
        
        try:
            results = self.client.search(
                collection_name=self.collection_name,
                data=[query_vector],
                limit=top_k,
                anns_field="text_vector",
                output_fields=output_fields
            )
            
            # 格式化结果
            formatted_results = []
            if results and len(results) > 0:
                for result in results[0]:
                    formatted_results.append({
                        "text": result["entity"].get("text", ""),
                        "db_id": result["entity"].get("db_id", 0),
                        "file_name": result["entity"].get("file_name", ""),
                        "file_path": result["entity"].get("file_path", ""),
                        "distance": result.get("distance", 0.0)
                    })
            
            return formatted_results
            
        except Exception as e:
            print(f"检索失败: {e}")
            return []
    
    def delete_by_file_id(self, file_id: int) -> bool:
        """
        根据文件ID删除向量
        
        Args:
            file_id: 文件ID
            
        Returns:
            是否删除成功
        """
        if not self.is_connected():
            raise ConnectionError("Milvus 未连接")
        
        try:
            self.client.delete(
                collection_name=self.collection_name,
                filter=f"db_id == {file_id}"
            )
            return True
        except Exception as e:
            print(f"删除向量失败: {e}")
            return False
    
    def get_collection_stats(self) -> Dict[str, Any]:
        """
        获取集合统计信息
        
        Returns:
            统计信息字典
        """
        if not self.is_connected():
            return {"error": "Milvus 未连接"}
        
        try:
            stats = self.client.get_collection_stats(self.collection_name)
            return stats
        except Exception as e:
            return {"error": str(e)}


# 全局 Milvus 服务实例
milvus_service = MilvusService()
