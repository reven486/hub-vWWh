"""
聊天服务模块
处理 RAG 问答相关的业务逻辑
"""
import os
import json
import uuid
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session
import openai

from app.models.models import ChatSession, ChatMessage
from app.schemas.schemas import (
    ChatRequest, 
    ChatResponseData, 
    RetrievalResult,
    ChatMessageResponse,
    ChatSessionResponse
)
from app.services.milvus_service import milvus_service
from app.core.config import settings

# 设置 HuggingFace 镜像
os.environ['HF_ENDPOINT'] = 'https://hf-mirror.com'


class ChatService:
    """聊天服务类"""
    
    def __init__(self):
        self.qwen_client = openai.OpenAI(
            api_key=settings.DASHSCOPE_API_KEY,
            base_url=settings.DASHSCOPE_BASE_URL,
        )
        self.bge_model = None
        self._init_embedding_model()
        
        self.rag_prompt_template = """基于资料回答的提问精简的回答下面的问题：{question}

相关资料: {context}

回答要求：
- 回答要客观，有逻辑，要基于只有的资料。
- 如果资料中包含图片链接，则单独一行进行输出，保留图的原始链接，不要修改任何连接路径，需要将图放在合适的相关内容的位置。
"""
    
    def _init_embedding_model(self):
        """初始化嵌入模型"""
        try:
            from sentence_transformers import SentenceTransformer
            self.bge_model = SentenceTransformer(settings.BGE_MODEL_PATH)
            print("BGE 模型加载成功")
        except Exception as e:
            print(f"BGE 模型加载失败: {e}")
            self.bge_model = None
    
    def encode_query(self, query: str) -> List[float]:
        """
        编码查询文本
        
        Args:
            query: 查询文本
            
        Returns:
            查询向量
        """
        if self.bge_model is None:
            raise RuntimeError("嵌入模型未加载")
        
        embedding = self.bge_model.encode(query, normalize_embeddings=True)
        return embedding.tolist()
    
    def retrieve_documents(
        self, 
        query: str, 
        top_k: int = 5
    ) -> List[RetrievalResult]:
        """
        检索相关文档
        
        Args:
            query: 查询文本
            top_k: 返回结果数量
            
        Returns:
            检索结果列表
        """
        # 编码查询
        query_vector = self.encode_query(query)
        
        # 检索
        raw_results = milvus_service.search_by_text(query_vector, top_k=top_k)
        
        # 处理图片路径
        results = []
        for result in raw_results:
            file_dir = os.path.basename(result["file_path"]).split(".")[0]
            processed_text = result["text"].replace(
                "images/", 
                f"./processed/{file_dir}/vlm/images/"
            )
            
            results.append(RetrievalResult(
                text=processed_text,
                db_id=result["db_id"],
                file_name=result["file_name"],
                file_path=result["file_path"],
                distance=result["distance"]
            ))
        
        return results
    
    def generate_response(
        self, 
        query: str, 
        context: str
    ) -> str:
        """
        生成 AI 回复
        
        Args:
            query: 用户问题
            context: 检索到的上下文
            
        Returns:
            AI 回复内容
        """
        prompt = self.rag_prompt_template.format(
            question=query,
            context=context
        )
        
        try:
            completion = self.qwen_client.chat.completions.create(
                model=settings.DASHSCOPE_MODEL,
                messages=[
                    {'role': 'system', 'content': 'You are a helpful assistant.'},
                    {'role': 'user', 'content': prompt}
                ]
            )
            return completion.choices[0].message.content
        except Exception as e:
            print(f"生成回复失败: {e}")
            return f"抱歉，生成回复时出现错误: {str(e)}"
    
    def create_session(self, db: Session, title: Optional[str] = None) -> ChatSession:
        """
        创建新会话
        
        Args:
            db: 数据库会话
            title: 会话标题
            
        Returns:
            创建的会话
        """
        session_id = str(uuid.uuid4())
        
        db_session = ChatSession(
            session_id=session_id,
            title=title or "新会话"
        )
        
        db.add(db_session)
        db.commit()
        db.refresh(db_session)
        
        return db_session
    
    def get_session_by_id(self, db: Session, session_id: str) -> Optional[ChatSession]:
        """
        根据ID获取会话
        
        Args:
            db: 数据库会话
            session_id: 会话ID
            
        Returns:
            会话或None
        """
        return db.query(ChatSession).filter(ChatSession.session_id == session_id).first()
    
    def get_or_create_session(
        self, 
        db: Session, 
        session_id: Optional[str] = None
    ) -> ChatSession:
        """
        获取或创建会话
        
        Args:
            db: 数据库会话
            session_id: 会话ID，为空则创建新会话
            
        Returns:
            会话
        """
        if session_id:
            session = self.get_session_by_id(db, session_id)
            if session:
                return session
        
        return self.create_session(db)
    
    def add_message(
        self, 
        db: Session, 
        session_id: str, 
        role: str, 
        content: str,
        retrieval_results: Optional[str] = None
    ) -> ChatMessage:
        """
        添加消息到会话
        
        Args:
            db: 数据库会话
            session_id: 会话ID
            role: 角色
            content: 内容
            retrieval_results: 检索结果JSON
            
        Returns:
            创建的消息
        """
        db_message = ChatMessage(
            session_id=session_id,
            role=role,
            content=content,
            retrieval_results=retrieval_results
        )
        
        db.add(db_message)
        db.commit()
        db.refresh(db_message)
        
        return db_message
    
    def chat(
        self, 
        db: Session, 
        request: ChatRequest
    ) -> ChatResponseData:
        """
        处理聊天请求
        
        Args:
            db: 数据库会话
            request: 聊天请求
            
        Returns:
            聊天响应数据
        """
        # 获取或创建会话
        session = self.get_or_create_session(db, request.session_id)
        
        # 保存用户消息
        self.add_message(db, session.session_id, "user", request.message)
        
        # 检索相关文档
        retrieval_results = self.retrieve_documents(
            request.message, 
            top_k=request.top_k
        )
        
        # 构建上下文
        context = "\n\n".join([r.text for r in retrieval_results])
        
        # 生成回复
        ai_response = self.generate_response(request.message, context)
        
        # 保存 AI 消息
        retrieval_json = json.dumps([r.model_dump() for r in retrieval_results], ensure_ascii=False)
        self.add_message(
            db, 
            session.session_id, 
            "assistant", 
            ai_response,
            retrieval_results=retrieval_json
        )
        
        return ChatResponseData(
            session_id=session.session_id,
            message=ai_response,
            retrieval_results=retrieval_results
        )
    
    def get_session_messages(
        self, 
        db: Session, 
        session_id: str
    ) -> List[ChatMessage]:
        """
        获取会话的所有消息
        
        Args:
            db: 数据库会话
            session_id: 会话ID
            
        Returns:
            消息列表
        """
        return db.query(ChatMessage).filter(
            ChatMessage.session_id == session_id
        ).order_by(ChatMessage.created_at).all()
    
    def get_sessions(
        self, 
        db: Session, 
        skip: int = 0, 
        limit: int = 100
    ) -> List[ChatSession]:
        """
        获取会话列表
        
        Args:
            db: 数据库会话
            skip: 跳过数量
            limit: 限制数量
            
        Returns:
            会话列表
        """
        return db.query(ChatSession).order_by(
            ChatSession.updated_at.desc()
        ).offset(skip).limit(limit).all()
    
    def delete_session(self, db: Session, session_id: str) -> bool:
        """
        删除会话
        
        Args:
            db: 数据库会话
            session_id: 会话ID
            
        Returns:
            是否删除成功
        """
        session = self.get_session_by_id(db, session_id)
        if not session:
            return False
        
        db.delete(session)
        db.commit()
        return True


# 全局聊天服务实例
chat_service = ChatService()
