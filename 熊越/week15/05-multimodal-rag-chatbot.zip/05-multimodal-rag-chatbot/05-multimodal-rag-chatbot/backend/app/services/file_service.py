"""
文件服务模块
处理文件相关的业务逻辑
"""
import os
import uuid
import shutil
from typing import List, Optional
from sqlalchemy.orm import Session
from kafka import KafkaProducer
import json

from app.models.models import File
from app.schemas.schemas import FileCreate, FileResponse
from app.core.config import settings


class FileService:
    """文件服务类"""
    
    ALLOWED_EXTENSIONS = {'.pdf', '.docx', '.txt', '.md'}
    
    def __init__(self):
        self.upload_dir = settings.UPLOAD_DIR
        self._ensure_upload_dir()
        self._init_kafka_producer()
    
    def _ensure_upload_dir(self):
        """确保上传目录存在"""
        if not os.path.exists(self.upload_dir):
            os.makedirs(self.upload_dir, exist_ok=True)
    
    def _init_kafka_producer(self):
        """初始化 Kafka 生产者"""
        try:
            self.producer = KafkaProducer(
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode('utf-8'),
                retries=3,
                retry_backoff_ms=1000
            )
            self.kafka_available = True
        except Exception as e:
            print(f"Kafka连接失败: {e}")
            self.producer = None
            self.kafka_available = False
    
    def _get_file_extension(self, filename: str) -> str:
        """获取文件扩展名"""
        return os.path.splitext(filename)[1].lower()
    
    def _is_allowed_file(self, filename: str) -> bool:
        """检查文件类型是否允许"""
        return self._get_file_extension(filename) in self.ALLOWED_EXTENSIONS
    
    def save_upload_file(self, file_content: bytes, original_filename: str) -> str:
        """
        保存上传的文件
        
        Args:
            file_content: 文件内容
            original_filename: 原始文件名
            
        Returns:
            保存后的文件路径
        """
        # 生成UUID作为文件名
        file_extension = self._get_file_extension(original_filename)
        save_name = str(uuid.uuid4())
        save_path = os.path.join(self.upload_dir, f"{save_name}{file_extension}")
        
        # 保存文件
        with open(save_path, "wb") as f:
            f.write(file_content)
        
        return save_path
    
    def create_file_record(
        self, 
        db: Session, 
        filename: str, 
        filepath: str,
        file_size: Optional[int] = None
    ) -> File:
        """
        创建文件记录
        
        Args:
            db: 数据库会话
            filename: 文件名
            filepath: 文件路径
            file_size: 文件大小
            
        Returns:
            创建的文件记录
        """
        file_type = self._get_file_extension(filename)
        
        db_file = File(
            filename=filename,
            filepath=filepath,
            filestate="已上传",
            file_size=file_size,
            file_type=file_type
        )
        
        db.add(db_file)
        db.commit()
        db.refresh(db_file)
        
        return db_file
    
    def send_to_kafka(self, file_id: int, file_name: str, file_path: str):
        """
        发送文件处理消息到 Kafka
        
        Args:
            file_id: 文件ID
            file_name: 文件名
            file_path: 文件路径
        """
        if not self.kafka_available or self.producer is None:
            print("Kafka不可用，跳过消息发送")
            return False
        
        try:
            message = {
                "file_name": file_name,
                "file_path": file_path,
                "id": file_id
            }
            self.producer.send(settings.KAFKA_TOPIC, value=message)
            self.producer.flush(timeout=5)
            return True
        except Exception as e:
            print(f"发送Kafka消息失败: {e}")
            return False
    
    def upload_file(
        self, 
        db: Session, 
        file_content: bytes, 
        filename: str
    ) -> File:
        """
        上传文件的完整流程
        
        Args:
            db: 数据库会话
            file_content: 文件内容
            filename: 文件名
            
        Returns:
            创建的文件记录
        """
        # 检查文件类型
        if not self._is_allowed_file(filename):
            raise ValueError(f"不支持的文件类型，仅支持: {', '.join(self.ALLOWED_EXTENSIONS)}")
        
        # 检查文件大小
        if len(file_content) > settings.MAX_FILE_SIZE:
            raise ValueError(f"文件大小超过限制: {settings.MAX_FILE_SIZE / 1024 / 1024}MB")
        
        # 保存文件
        save_path = self.save_upload_file(file_content, filename)
        
        # 创建数据库记录
        file_record = self.create_file_record(
            db=db,
            filename=filename,
            filepath=save_path,
            file_size=len(file_content)
        )
        
        # 发送到 Kafka
        self.send_to_kafka(file_record.id, filename, save_path)
        
        return file_record
    
    def get_files(self, db: Session, skip: int = 0, limit: int = 100) -> List[File]:
        """
        获取文件列表
        
        Args:
            db: 数据库会话
            skip: 跳过数量
            limit: 限制数量
            
        Returns:
            文件列表
        """
        return db.query(File).order_by(File.created_at.desc()).offset(skip).limit(limit).all()
    
    def get_file_by_id(self, db: Session, file_id: int) -> Optional[File]:
        """
        根据ID获取文件
        
        Args:
            db: 数据库会话
            file_id: 文件ID
            
        Returns:
            文件记录或None
        """
        return db.query(File).filter(File.id == file_id).first()
    
    def delete_file(self, db: Session, file_id: int) -> bool:
        """
        删除文件
        
        Args:
            db: 数据库会话
            file_id: 文件ID
            
        Returns:
            是否删除成功
        """
        file_record = self.get_file_by_id(db, file_id)
        if not file_record:
            return False
        
        # 删除物理文件
        try:
            if os.path.exists(file_record.filepath):
                os.remove(file_record.filepath)
        except Exception as e:
            print(f"删除物理文件失败: {e}")
        
        # 删除数据库记录
        db.delete(file_record)
        db.commit()
        
        return True
    
    def get_file_count(self, db: Session) -> int:
        """
        获取文件总数
        
        Args:
            db: 数据库会话
            
        Returns:
            文件总数
        """
        return db.query(File).count()


# 全局文件服务实例
file_service = FileService()
