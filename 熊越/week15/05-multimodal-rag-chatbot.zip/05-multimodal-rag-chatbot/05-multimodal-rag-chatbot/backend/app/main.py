"""
FastAPI 应用主入口
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app.models.database import init_db
from app.api.v1.api import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    应用生命周期管理
    """
    # 启动时执行
    print("正在初始化数据库...")
    init_db()
    print("数据库初始化完成")
    
    yield
    
    # 关闭时执行
    print("应用正在关闭...")


def create_application() -> FastAPI:
    """
    创建 FastAPI 应用实例
    """
    application = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description="""
        多模态 RAG 聊天机器人 API
        
        ## 功能特性
        
        * **文件管理**: 上传、查询、删除文档文件
        * **RAG 问答**: 基于检索增强生成的智能问答
        * **会话管理**: 支持多轮对话和会话历史
        * **多模态支持**: 支持文本、图片等多种内容类型
        
        ## 技术栈
        
        * **嵌入模型**: BGE-small-zh-v1.5
        * **多模态模型**: jina-clip-v2
        * **大语言模型**: DeepSeek-V4-Pro (via DashScope)
        * **向量数据库**: Milvus
        * **消息队列**: Kafka
        """,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan
    )
    
    # 配置 CORS
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.allowed_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 注册路由
    application.include_router(
        api_router,
        prefix="/api/v1"
    )
    
    return application


# 创建应用实例
app = create_application()


@app.get("/", tags=["根路径"])
def root():
    """
    根路径 - 返回 API 基本信息
    """
    return {
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs_url": "/docs",
        "api_prefix": "/api/v1"
    }


@app.get("/health", tags=["健康检查"])
def health():
    """
    健康检查端点
    """
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        workers=1
    )
