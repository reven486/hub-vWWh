"""
数据模型定义
包含所有数据库表对应的 SQLAlchemy 模型
"""
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, Float, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.models.database import Base


class File(Base):
    """文件表 - 核心文件管理系统"""
    __tablename__ = 'files'
    
    # 主键和基本信息
    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(255), nullable=False, comment="原始文件名")
    filepath = Column(String(1000), nullable=False, comment="存储路径")
    filestate = Column(String(20), nullable=False, default="已上传", comment="处理状态")
    
    # 时间戳
    created_at = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    
    # 文件元数据
    file_size = Column(Integer, nullable=True, comment="文件大小(字节)")
    file_type = Column(String(50), nullable=True, comment="文件类型")
    
    # 索引配置
    __table_args__ = (
        {'sqlite_autoincrement': True},
    )


class ChatSession(Base):
    """聊天会话表 - 存储对话历史"""
    __tablename__ = 'chat_sessions'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(100), unique=True, nullable=False, comment="会话ID")
    title = Column(String(255), nullable=True, comment="会话标题")
    created_at = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, comment="更新时间")
    
    # 关联消息
    messages = relationship("ChatMessage", back_populates="session", cascade="all, delete-orphan")


class ChatMessage(Base):
    """聊天消息表 - 存储单条消息"""
    __tablename__ = 'chat_messages'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(100), ForeignKey('chat_sessions.session_id'), nullable=False)
    role = Column(String(20), nullable=False, comment="角色: user/assistant/system")
    content = Column(Text, nullable=False, comment="消息内容")
    created_at = Column(DateTime, default=datetime.utcnow, comment="创建时间")
    
    # 关联的检索结果（JSON格式存储）
    retrieval_results = Column(Text, nullable=True, comment="检索结果JSON")
    
    # 关联会话
    session = relationship("ChatSession", back_populates="messages")
