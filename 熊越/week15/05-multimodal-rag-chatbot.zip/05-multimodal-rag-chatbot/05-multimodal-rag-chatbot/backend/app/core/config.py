"""
应用配置模块
使用 Pydantic Settings 管理环境变量和配置
"""
from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """应用配置类"""
    
    # 应用基本信息
    APP_NAME: str = "Multimodal RAG Chatbot API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = Field(default=False, env="DEBUG")
    
    # 数据库配置
    DATABASE_URL: str = Field(default="sqlite:///./db.db", env="DATABASE_URL")
    
    # Milvus 向量数据库配置
    MILVUS_URI: str = Field(..., env="MILVUS_URI")
    MILVUS_TOKEN: str = Field(..., env="MILVUS_TOKEN")
    MILVUS_COLLECTION: str = Field(default="rag_data_new", env="MILVUS_COLLECTION")
    
    # Kafka 配置
    KAFKA_BOOTSTRAP_SERVERS: str = Field(default="localhost:9092", env="KAFKA_BOOTSTRAP_SERVERS")
    KAFKA_TOPIC: str = Field(default="rag-data", env="KAFKA_TOPIC")
    
    # 模型路径配置
    BGE_MODEL_PATH: str = Field(
        default="/root/autodl-tmp/models/BAAI/bge-small-zh-v1.5",
        env="BGE_MODEL_PATH"
    )
    CLIP_MODEL_PATH: str = Field(
        default="/root/autodl-tmp/models/jinaai/jina-clip-v2",
        env="CLIP_MODEL_PATH"
    )
    
    # DashScope API 配置
    DASHSCOPE_API_KEY: str = Field(..., env="DASHSCOPE_API_KEY")
    DASHSCOPE_BASE_URL: str = Field(
        default="https://dashscope.aliyuncs.com/compatible-mode/v1",
        env="DASHSCOPE_BASE_URL"
    )
    DASHSCOPE_MODEL: str = Field(default="deepseek-v4-pro", env="DASHSCOPE_MODEL")
    
    # MinerU 配置
    MINERU_ENDPOINT: str = Field(default="http://127.0.0.1:30000", env="MINERU_ENDPOINT")
    
    # 文件存储配置
    UPLOAD_DIR: str = Field(default="./uploads", env="UPLOAD_DIR")
    PROCESSED_DIR: str = Field(default="./processed", env="PROCESSED_DIR")
    MAX_FILE_SIZE: int = Field(default=104857600, env="MAX_FILE_SIZE")  # 100MB
    
    # API 安全配置
    SECRET_KEY: str = Field(..., env="SECRET_KEY")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    
    # CORS 配置
    ALLOWED_ORIGINS: str = Field(default="http://localhost:3000,http://localhost:8501", env="ALLOWED_ORIGINS")
    
    @property
    def allowed_origins_list(self) -> List[str]:
        """将 ALLOWED_ORIGINS 字符串转换为列表"""
        return [origin.strip() for origin in self.ALLOWED_ORIGINS.split(",")]
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# 全局配置实例
settings = Settings()
