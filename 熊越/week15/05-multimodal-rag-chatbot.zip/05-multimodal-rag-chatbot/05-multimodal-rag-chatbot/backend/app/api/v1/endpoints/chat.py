"""
聊天 API 路由
处理 RAG 问答、会话管理等操作
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.schemas.schemas import (
    ChatRequest,
    ChatResponse,
    ChatSessionResponse,
    ChatSessionListResponse,
    ChatMessageResponse,
    DataResponse
)
from app.services.chat_service import chat_service

router = APIRouter()


@router.post("/send", response_model=ChatResponse, summary="发送消息")
def send_message(
    request: ChatRequest,
    db: Session = Depends(get_db)
):
    """
    发送消息进行 RAG 问答
    
    - 如果提供了 session_id，则继续已有会话
    - 如果没有提供 session_id，则自动创建新会话
    - 系统会自动检索相关文档并生成回答
    """
    try:
        response_data = chat_service.chat(db, request)
        
        return ChatResponse(
            code=200,
            message="success",
            data=response_data
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"处理消息失败: {str(e)}"
        )


@router.get("/sessions", response_model=ChatSessionListResponse, summary="获取会话列表")
def get_sessions(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    获取所有聊天会话列表
    
    - 按更新时间倒序排列
    - 支持分页
    """
    try:
        sessions = chat_service.get_sessions(db, skip=skip, limit=limit)
        
        return ChatSessionListResponse(
            code=200,
            message="success",
            data=[ChatSessionResponse.model_validate(s) for s in sessions],
            total=len(sessions)
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取会话列表失败: {str(e)}"
        )


@router.get("/sessions/{session_id}", response_model=ChatSessionResponse, summary="获取会话详情")
def get_session(
    session_id: str,
    db: Session = Depends(get_db)
):
    """
    获取指定会话的详情，包括所有消息
    """
    try:
        session = chat_service.get_session_by_id(db, session_id)
        
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="会话不存在"
            )
        
        return ChatSessionResponse.model_validate(session)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取会话详情失败: {str(e)}"
        )


@router.get("/sessions/{session_id}/messages", response_model=List[ChatMessageResponse], summary="获取会话消息")
def get_session_messages(
    session_id: str,
    db: Session = Depends(get_db)
):
    """
    获取指定会话的所有消息
    """
    try:
        messages = chat_service.get_session_messages(db, session_id)
        
        return [ChatMessageResponse.model_validate(m) for m in messages]
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取消息失败: {str(e)}"
        )


@router.post("/sessions", response_model=ChatSessionResponse, summary="创建新会话")
def create_session(
    title: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    创建新的聊天会话
    """
    try:
        session = chat_service.create_session(db, title=title)
        
        return ChatSessionResponse.model_validate(session)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"创建会话失败: {str(e)}"
        )


@router.delete("/sessions/{session_id}", response_model=DataResponse, summary="删除会话")
def delete_session(
    session_id: str,
    db: Session = Depends(get_db)
):
    """
    删除指定会话及其所有消息
    """
    try:
        success = chat_service.delete_session(db, session_id)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="会话不存在"
            )
        
        return DataResponse(
            code=200,
            message="会话删除成功",
            data={"session_id": session_id}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"删除会话失败: {str(e)}"
        )
