"""
文件管理 API 路由
处理文件上传、查询、删除等操作
"""
from typing import List
from fastapi import APIRouter, Depends, UploadFile, File as FastAPIFile, HTTPException, status
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.models.models import File as FileModel
from app.schemas.schemas import (
    FileResponse, 
    FileUploadResponse, 
    FileListResponse,
    DataResponse
)
from app.services.file_service import file_service
from app.services.milvus_service import milvus_service

router = APIRouter()


@router.post("/upload", response_model=FileUploadResponse, summary="上传文件")
async def upload_file(
    file: UploadFile = FastAPIFile(..., description="要上传的文件，支持 pdf, docx, txt, md"),
    db: Session = Depends(get_db)
):
    """
    上传文件到系统
    
    - 支持格式: pdf, docx, txt, md
    - 文件大小限制: 100MB
    - 上传后会自动发送到 Kafka 进行异步处理
    """
    try:
        # 读取文件内容
        content = await file.read()
        
        # 上传文件
        file_record = file_service.upload_file(
            db=db,
            file_content=content,
            filename=file.filename
        )
        
        return FileUploadResponse(
            code=200,
            message="文件上传成功",
            data=FileResponse.model_validate(file_record)
        )
        
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"文件上传失败: {str(e)}"
        )


@router.get("/list", response_model=FileListResponse, summary="获取文件列表")
def get_files(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db)
):
    """
    获取所有上传的文件列表
    
    - 按上传时间倒序排列
    - 支持分页
    """
    try:
        files = file_service.get_files(db, skip=skip, limit=limit)
        total = file_service.get_file_count(db)
        
        return FileListResponse(
            code=200,
            message="success",
            data=[FileResponse.model_validate(f) for f in files],
            total=total
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取文件列表失败: {str(e)}"
        )


@router.get("/{file_id}", response_model=FileUploadResponse, summary="获取文件详情")
def get_file(
    file_id: int,
    db: Session = Depends(get_db)
):
    """
    根据ID获取文件详情
    """
    try:
        file_record = file_service.get_file_by_id(db, file_id)
        
        if not file_record:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="文件不存在"
            )
        
        return FileUploadResponse(
            code=200,
            message="success",
            data=FileResponse.model_validate(file_record)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"获取文件详情失败: {str(e)}"
        )


@router.delete("/{file_id}", response_model=DataResponse, summary="删除文件")
def delete_file(
    file_id: int,
    db: Session = Depends(get_db)
):
    """
    删除指定文件
    
    - 删除数据库记录
    - 删除本地文件
    - 删除 Milvus 中的向量数据
    """
    try:
        # 先删除 Milvus 向量
        try:
            milvus_service.delete_by_file_id(file_id)
        except Exception as e:
            print(f"删除Milvus向量失败: {e}")
        
        # 删除文件记录和物理文件
        success = file_service.delete_file(db, file_id)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="文件不存在"
            )
        
        return DataResponse(
            code=200,
            message="文件删除成功",
            data={"file_id": file_id}
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"删除文件失败: {str(e)}"
        )
