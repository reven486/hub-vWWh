"""
API 路由聚合模块
"""
from fastapi import APIRouter
from app.api.v1.endpoints import files, chat, system

api_router = APIRouter()

# 文件管理路由
api_router.include_router(
    files.router,
    prefix="/files",
    tags=["文件管理"]
)

# 聊天路由
api_router.include_router(
    chat.router,
    prefix="/chat",
    tags=["RAG问答"]
)

# 系统路由
api_router.include_router(
    system.router,
    prefix="/system",
    tags=["系统"]
)
