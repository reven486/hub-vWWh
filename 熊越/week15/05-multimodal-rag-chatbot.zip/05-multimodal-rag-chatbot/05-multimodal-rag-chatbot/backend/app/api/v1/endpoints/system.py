"""
系统 API 路由
处理系统状态、健康检查等操作
"""
from fastapi import APIRouter
from app.schemas.schemas import StatusResponse, SystemStatus
from app.services.milvus_service import milvus_service
from app.services.file_service import file_service
from app.core.config import settings

router = APIRouter()


@router.get("/health", response_model=StatusResponse, summary="健康检查")
def health_check():
    """
    系统健康检查接口
    
    返回系统各组件的连接状态
    """
    milvus_connected = milvus_service.is_connected()
    kafka_connected = file_service.kafka_available
    
    status = SystemStatus(
        status="healthy" if milvus_connected else "degraded",
        version=settings.APP_VERSION,
        milvus_connected=milvus_connected,
        kafka_connected=kafka_connected
    )
    
    return StatusResponse(
        code=200,
        message="success",
        data=status
    )


@router.get("/info", summary="系统信息")
def get_system_info():
    """
    获取系统基本信息
    """
    return {
        "app_name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "features": {
            "file_upload": True,
            "rag_chat": True,
            "session_management": True,
            "multimodal_support": True
        },
        "supported_file_types": [".pdf", ".docx", ".txt", ".md"],
        "models": {
            "embedding": "BGE-small-zh-v1.5",
            "multimodal": "jina-clip-v2",
            "llm": settings.DASHSCOPE_MODEL
        }
    }


@router.get("/milvus/stats", summary="Milvus 统计信息")
def get_milvus_stats():
    """
    获取 Milvus 向量数据库的统计信息
    """
    stats = milvus_service.get_collection_stats()
    
    return {
        "code": 200,
        "message": "success",
        "data": stats
    }
